import json
import re

pattern = r'Check \"Factory reset\" key'
  
##------ JSON string
#a = '{"name": "Bob", "languages": "English"}'
  
##------ deserializes into dict and returns dict.
#y = json.loads(a)
  
#print("JSON string = ", y)
#print()

  
#---------XU LY FILE CU  
# JSON file
f = open ('C:\\Users\\V0916166\\Desktop\\JSONLOG\\file goc.json', "r")
  
# Reading from file
str_data = f.read().replace("'", "-")
org_data = json.loads(str_data)
  
##-------- Iterating through the json list
#for i in org_data['TestContext']:
#    print(i)
  
# Closing file
f.close()

#-------------XU LY FILE MOI
new_data = '{\
    "TestGate": "",\
    "ModelName": "",\
    "TestStation": "",\
    "TestStationName": "",\
    "TEST_DATA":{}\
}'
new_data_json = json.loads(new_data)
new_data_json["TestGate"] = org_data['TestContext']["TestGate"]
new_data_json["ModelName"] = org_data['TestContext']["ModelName"]
new_data_json["TestStation"] = org_data['TestContext']["TestStation"]
new_data_json["TEST_DATA"] = {}

org_test_data_list = org_data['TestContext']["TestSteps"]

 
for i in range(0,len(org_test_data_list)):
    print(i)
    idata = str(org_test_data_list[i]).replace("'", '"') 
    idata = re.sub(pattern, 'Check Factory reset key', idata)
    org_test_data_json = json.loads(idata)
    #print(org_test_data_json)
    new_data_json["TEST_DATA"][org_test_data_json["TestName"]+'_TEST_TIME'] = org_test_data_json["TestTime"]



#for i in new_data_json:
#    print(i)

json_object = json.dumps(new_data_json, indent=4)
 
#----------- Writing json FILE
with open("file_nay_la_moi_nhat.json", "w") as outfile:
    outfile.write(json_object)

