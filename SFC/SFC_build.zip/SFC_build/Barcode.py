
import pyzbar.pyzbar as pyzbar
import numpy as np
import cv2
from PyQt4 import QtCore,QtTest
from ast import literal_eval
class Barcode_Read(QtCore.QThread):
    def __init__(self,cam_id,code,length, prefix,file,parent=None):
        super(Barcode_Read, self).__init__(parent)
        self.cam_id = int(cam_id)
        self.code = code

        self.length = length

        self.prefix = prefix

        self.file = file

        self.barcode_old = ""
        self._isRunning = True

    def cam_init(self):
        try:
            self.capture = cv2.VideoCapture(self.cam_id)
            self.capture.set(3, 1920)
            self.capture.set(3, 1080)
            #self.capture.set(cv2.CAP_PROP_BRIGHTNESS, 60)
            #self.capture.set(cv2.CAP_PROP_CONTRAST, 5)
            #self.capture.set(cv2.CAP_PROP_SETTING, 20)
            try:
                cv2.namedWindow('Current', cv2.WINDOW_NORMAL)
            except:
                pass
        except Exception as e:
            #print "Open CAM Issue \n", e
            pass

    def increase_brightness(self, img, value=0):
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        lim = 255-value
        v[v > lim] = 255
        v[v <= lim] += value
        final_hsv = cv2.merge((h, s, v))
        frame = cv2.cvtColor(final_hsv, cv2.COLOR_HSV2BGR)
        return frame
    def run(self):
        try:
            while self.capture.isOpened():
                file = open('D:\\brightcam.txt', 'r')
                cfile = file.read()
                cfile = literal_eval(cfile)
                #print cfile[0], cfile[1]
                self.capture.set(cv2.CAP_PROP_BRIGHTNESS, int(cfile[0]))
                self.capture.set(cv2.CAP_PROP_CONTRAST, int(cfile[1]))

                file.close()
                pre_barcode = ''
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                ret, frame = self.capture.read()
                frame = self.increase_brightness(frame, int(cfile[2]))

                decodedObjects = pyzbar.decode(frame)

                #cv2.imshow('Current', frame)
                for obj in decodedObjects:
                    #(x, y, w, h) = obj.rect

                    (x, y, w, h) = obj.rect
                    frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                    barcodeData = obj.data.decode("utf-8")
                    #print barcodeData
                    #barcodeData= str(obj.data,'utf-8')
                    barcodeType = obj.type
                    if (str(barcodeType) == self.code):
                        self.barcode= str(barcodeData)
                        if len(self.barcode) == int(self.length):
                            if self.barcode != self.barcode_old:
                                if (self.barcode.find(self.prefix) == 0):
                                    try:
                                        self.f = open(self.file, 'r+')
                                        self.scheck = self.f.readline()
                                        if self.barcode != self.scheck:
                                            self.f.truncate(0)
                                            self.f.writelines(self.barcode)
                                            try:
                                                self.emit(QtCore.SIGNAL('Barcode'), self.barcode)
                                            except:
                                                pass
                                            self.barcode_old = self.barcode
                                        self.f.close()
                                    except Exception as e:
                                        #print "Open read old barcode issue \n", e
                                        pass
                    try:
                        #print "show cam"
                        cv2.imshow('Current', frame)
                    except Exception as e:
                        #print "show cam issue \n", e
                        pass
                    QtTest.QTest.qWait(100)
                cv2.imshow('Current', frame)
        except Exception as e:
            print ('Current: ', e)
    '''def run(self):
        while True and self._isRunning == True:

            # To quit this program press q.
            """
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            # Breaks down the video into frames"""
            frame = None

            try:
                ret, frame = self.capture.read()
            except:
                pass
            try:
                cv2.imshow('Current', frame)
            except:
                print 'Show cam issue'
                pass
            if (frame is not None):
                self.gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Binary convert before scan
                self.images = Image.fromarray(self.gray)

                self.width, self.height = self.images.size
                self.zbar_image = zbar.Image(self.width, self.height, 'Y800', self.images.tobytes())
            # Scans the zbar setting.b
                self.scanner = zbar.ImageScanner()
                self.scanner.scan(self.zbar_image)
                for decoded in self.zbar_image:
                    if decoded.data is not None:
                        self.bottom_right_correr = [item for item in decoded.location]
                        self.s = self.bottom_right_correr[0]
                        self.x, self.y = self.s[:2]
                        try:
                            frame = cv2.rectangle(frame, (self.x, self.y), (self.x, self.y + 30), (0, 255, 0), 2)
                        except:
                            pass
                        if (str(decoded.type) == self.code):

                            self.barcode = decoded.data
                            if len(self.barcode) == int(self.length):
                                if self.barcode!=self.barcode_old:
                                    if (self.barcode.find(self.prefix) == 0):
                                        try:
                                            self.f = open(self.file, 'r+')
                                            self.scheck = self.f.readline()
                                            if self.barcode != self.scheck:
                                                self.f.truncate(0)
                                                self.f.writelines(self.barcode)
                                                try:
                                                    self.emit(QtCore.SIGNAL('Barcode'), self.barcode)
                                                except:
                                                    pass
                                                self.barcode_old = self.barcode
                                            self.f.close()
                                        except:
                                            print "Open read old barcode issue"
                                            pass
            try:
                cv2.imshow('Current', frame)
            except:
                print "show cam issue"
                pass
            QtTest.QTest.qWait(100)'''

    def stop(self):
        self._isRunning = False
        self.capture.release()
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
        cv2.destroyWindow('Current')


