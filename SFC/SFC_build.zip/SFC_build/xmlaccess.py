
import xml.etree.ElementTree as ET
class xml_access():
    def __init__(self, filename):
        self.filename = filename
        self.tree = ET.parse(self.filename)
        self.root = self.tree.getroot()
    def xml_com_name(self,kind,name):
        self.name = self.root.find(kind)
        self.item = self.name.findall(name)
        return self.item