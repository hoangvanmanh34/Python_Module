import time
import serial
import os
import telnetlib
import sys
class Demo:
    def __init__(self, **args):
        self.ser = None
        self.iTelnet = None
        self.ip = '192.168.1.254'
        self.userName = 'superman'
        self.password = 'superman'
        self.expectLogin = '=>'
        self.expectCMD = '{superman}=>'
        self.LoginDUT(self.ip, self.userName, self.password, 1, self.expectLogin)
        icmd = self.Check_Command()
        iResponse = self.Send_command(icmd, 1, self.expectCMD)[1]
        # self.Send_Command("env get var _MACADDR",1,"{superman}=>")
        self.SaveFile(iResponse)
    def LoginDUT(self,ipAds,iport,iusername,ipassword,itimeout,strExpect):
        global tn
        try:
            self.iTelnet=telnetlib.Telnet(ipAds,port=iport,timeout=itimeout)
            time.sleep(0.5)
            self.iTelnet.write(iusername.encode("ascii")+ b"\r\n")
            time.sleep(0.5)
            self.iTelnet.write(ipassword.encode('ascii')+b'\r\n')
            time.sleep(2)
            res=self.iTelnet.read_until(strExpect.encode('ascii'),itimeout).decode('ascii')
            return {True,res}
        except Exception as e:
            return {False,res +"_"+str(e)}
    def Send_command(self,strCMD,itimeout,strExpect):
        try:
            self.iTelnet.write(strCMD.encode())
            res=self.iTelnet.read_until(strExpect.encode(),itimeout)
            return [True,res]
        except Exception as e:
            return [False,res +'_'+str(e)]

    def Getcontent(self,buf,istart,istop):
        posstart=buf.find(istart)+len(istart)
        buf1=buf[posstart:len(istart)]
        posend=buf.find(istop)
        if istop=="":
            posend=len(buf1)
        strresult=buf1[0:posend]
        return strresult

    def Check_Command(self, ifiledata=''):
        fileName = 'D:\\cmdFile.txt'
        ifiledata = self.Open_File()
        cmd1 = self.GetContent(ifiledata, 'COMMAND_1: ', '\n')
        # cmd2 = self.GetContent(ifiledata, 'COMMAND2: ' ,'\n')
        # strCommands = 'COMMAND_1: ' +cmd1 + '\n' + 'COMMAND2: ' + cmd2 + '\n'
        return cmd1
    def SaveFile(self,strCommands=''):
        try:
            log_file=open("Save_commands.txt",'a')
            log_file.write(strCommands)
            log_file.close()
        except Exception as e:
            print (e)
    def OpenFile(self,Filename=''):
        try:
            iFile=open(Filename,'r')
            ifiledata=iFile.read()
            iFile.close()
            return ifiledata
        except Exception as e:
            print e
    def OpenCOM(self,iserial):
        try:
            self.ser=serial.Serial(iserial)
            print self.ser.name
            time.sleep(0.5)
            self.ser.flush()
            print "COM opened"
        except Exception as e:
            print "Open Com fail"
            print e
    def CloseCOM(self):
        try:
            self.ser.flush()
            time.sleep(0.5)
            self.ser.close()
        except Exception as e:
            return True
            print e
    def GetIn(self):
        data=''
        if not self.ser.is_open():
            print 're open COM'
            self.OpenCOM()
        time.sleep(0.5)
        data=self.ser.read_all().strip()
        self.ser.flush()
        if data != b'':
            print(self.ser.name)
            print('Fixture:' + str(data))
        return data

    def Send_COM(self, scmd):
        try:
            print(scmd)
            end = '\x0d\x0a'
            self.ser.write(scmd.encode() + end.encode())  # +'\r\n')#
        except Exception as e:
            print('send to com fail')
            print(e)
