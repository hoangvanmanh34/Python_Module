import PyQt4,telnetlib,subprocess,os
from PyQt4 import QtCore
class TELNET(QtCore.QThread):
    def __init__(self,host,port, parent=None):
        super(TELNET, self).__init__(parent)
        self.host = host
        self.port = port
        try:
            self.Section = telnetlib.Telnet(self.host,self.port,timeout=40000)
            self.Section.set_debuglevel(40000)
        except:
            print "Can not telnet"
    def TELNET_RECIVE(self,s_string):

        try:
            val = self.Section.read
            print val
        except:
            print "read error"

        #self.emit(QtCore.SIGNAL('TELNET_INFO'), val)
    def TELNET_RECIVE_EXPECT(self,s_string):
        val = ''
        try:
            val = self.Section.read_until(s_string,timeout=10)

        except:
            print "read Error"
        return val

    def TELNET_RECIVE_EXPECT1(self, s_string):
        val = ''
        try:
            val = self.Section.read_all(s_string,timeout=10000)
            # print val
        except:
            print val
        return val
    def TELNET_SENT(self,s_string):
        self.Section.write(s_string)
    def TELNET_CLOSE(self):
        self.Section.close()
