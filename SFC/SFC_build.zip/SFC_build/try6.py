def consumableread(filename,reference_char):
    with open(filename, 'r') as f:
        textfile_tempa = f.readlines()
        print textfile_tempa
        resultindex = textfile_tempa.index(reference_char+"\n") + 1
        testresult = textfile_tempa[resultindex].rstrip("\r\n")
        return  testresult
def updateconsumable(filename,infoupdate):
    with open(filename,'w') as f:
        f.writelines(infoupdate)

list = ['$START$\n', '$DEVICES1$\n', '10\n', '$DEVICES2$\n', '10\n', '$DEVICES3$\n', '10\n', '$DEVICES4$\n', '10\n', '$DEVICES5$\n', '10\n', '$END$']

list[2] = "100\n"
print list
s = consumableread("E:\\Program\study\\python\\SFC\\barcode\\consumable.txt","$DEVICES1$")
print s