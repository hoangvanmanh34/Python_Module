
import os
print os.getcwd()
file = os.getcwd()+"\\uut.txt"
print file
try:

    f = open(file, 'r+')
    scheck = f.readline()
    print scheck
    f.close()
except:
    print "Open read old barcode issue"
    pass