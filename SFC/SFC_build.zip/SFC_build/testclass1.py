#import socket,hashlib,psutil #for sockets
import sys,os,glob,shutil,datetime ,subprocess#for exit
import socket
from PyQt4 import QtCore,QtTest
import time
#import FTP_Trans
from os import path
import ftplib
from datetime import time
import xmlaccess
class SocketServer(QtCore.QThread):
    def __init__(self,SERVER_IP,SERVER_PORT,parent=None):
        super(SocketServer, self).__init__(parent)
        self.SERVER_IP = SERVER_IP
        self.SERVER_PORT = int(SERVER_PORT)

        try:
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error, msg:
            print 'Failed to create socket. Error code: ' + str(msg[0]) + ' , Error message : '
            sys.exit()
        try:
            self.remote_ip = socket.gethostbyname(self.SERVER_IP)
        except socket.gaierror:
            print 'Hostname could not be resolved. Exiting'
            sys.exit()
        print 'Ip address of ' + self.SERVER_IP + ' is ' +self.remote_ip

    def SERVERConnect(self):
        self.s.connect((self.SERVER_IP,self.SERVER_PORT))
        print 'Socket Connected to ' + self.SERVER_IP + ' on ip ' + self.remote_ip
    def SentToServer(self,cmd):
        try:
            self.s.sendall(cmd)
        except socket.error:
              print 'Send failed'
    def CloseConnection(self):
        self.s.close()
    def run(self):
        while 1:
            val = self.s.recv(8192)
            if (val!=None):
                self.emit(QtCore.SIGNAL('SERVER'),val)

    def stop(self):
        self.s.close()
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True

#----------------------------------------------------Analysis Log-------------------------------------------------------
import xmlaccess

class LogAnalysis(QtCore.QThread):
    settingfile = "./setting.xml"
    sig_log=QtCore.pyqtSignal(str)
    xml1=xmlaccess.xml_access(settingfile)

    def __init__(self, parent=None):
        super(LogAnalysis, self).__init__(parent)
        self.projectname=self.XML_GET(self.xml1,"Project","project_name")
        self.station=self.XML_GET(self.xml1,"Project","project_station")
        self.datefolder=str(datetime.datetime.now().__format__('%d-%m-%Y'))
        self.station_name=socket.gethostname()
        self.ftppth='Logs/'+self.projectname+'/'+self.station+'/'+self.datefolder+'/'+self.station_name
        #if not os.path.isdir(self.ftppth):
            #os.makedirs(self.ftppth)
        self.server_name=self.XML_GET(self.xml1,"Project","Server_IP")
        print ("name: "+ str(self.server_name))
        self.server_user=self.XML_GET(self.xml1,"Project","Server_User")
        print ("user: "+str(self.server_user))
        self.server_psw=self.XML_GET(self.xml1,"Project","Server_password")
        print ("password: "+str(self.server_psw))
        self.isWorking=True

    def XML_GET(self, XMLACESS, MainField, ClienField):
        self.XMLDATA = XMLACESS.xml_com_name(MainField, ClienField)
        for ID in self.XMLDATA:
            self.xmldata = ID.get('name')
            return self.xmldata
    def __del__(self):
        self.isWorking=False
        self.wait()


    def Create_FTP_Folder(self,working_dir):
        try:
            self.ftp_connection.cwd(working_dir) #change work folder,if fail it create folder directly
        except:
            self.ftp_connection.mkd(working_dir)
            self.ftp_connection.cwd(working_dir)

    def Create_FTP_Dir(self,working_dir):
        try:
            folder_list=working_dir.split('/')
            flen=len(folder_list)-1
            idir=folder_list[0]
            for i in range(0,flen):
                idir = folder_list[i]
                self.Create_FTP_Folder(idir)
        except Exception as e:
            print('create_ftp_dir:',e)

    def Upload_File(self,server,user,password,filepath,savepath):
        bResult=False
        try:
            self.ftp_connection=ftplib.FTP(server,user,password)
            self.ftp_connection.set_pasv(False)
            fh=open(filepath,'rb')
            filename=os.path.basename(filepath)
            self.Create_FTP_Dir(savepath)
            if self.ftp_connection.storbinary('STOR '+filename,fh):  #Upload files
                bResult=True
            fh.close()
            return bResult
        except Exception as e:
            print('print ftp:',e)
            return False

    def run(self):

        os.chdir("C:\\Phoenix\\Report\\QMS")
        while True:
            QtTest.QTest.qWait(5000)
            for file in glob.glob("*.txt"):
                if file is not None:
                    #self.logfile = "C:\\Traces\\" + file
                    self.logfile = "C:\\Phoenix\\Report\\QMS\\" + file
                    try:
                        with open(self.logfile, 'r') as f:
                            textfile_temp = f.readlines()
                            self.resultindex = textfile_temp.index("$Result$\n") + 1
                            self.md5index = textfile_temp.index("END\n") - 1
                            valresult = textfile_temp[self.md5index].rstrip("\r\n")[0:33]
                            self.testresult = textfile_temp[self.resultindex].rstrip("\r\n")

                            if (self.testresult.find("G") != -1):
                                valresult = valresult + "GOOD"
                                #self.emit(QtCore.SIGNAL("Result"),valresult)
                                self.emit(QtCore.SIGNAL('Result'), valresult)
                            elif (self.testresult.find("B") != -1):
                                self.errorcode_index = textfile_temp.index("$Failure_Code$\n") + 1
                                valresult = valresult + "_NG_" + textfile_temp[self.errorcode_index].rstrip("\r\n")
                                self.emit(QtCore.SIGNAL('Result'), valresult)
                                print valresult
                            #f.close()
                    except:
                        # f.close()
                        pass
                    '''
                    location="D:\\Traces_log\\"+str(datetime.datetime.now().__format__('%d-%m-%Y'))
                    try:
                        os.makedirs(location)
                    except:
                        pass
                    try:
                        self.local_backupfile=location+'\\'+file
                        #self.logfile='C:\\Traces\\'+file
                        self.logfile = 'C:\\Phoenix\\Report\\QMS\\' + file
                        self.ftpfile = self.ftppth + '/' + file
                        self.Upload_File(self.server_name, self.server_user, self.server_psw, self.logfile,
                                         self.ftpfile)
                        shutil.move(self.logfile,self.local_backupfile)
                    except:
                        pass
                    '''




    def stop(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped=True
        self.terminated=True
#-------------------------------------Save Telnet log-------------------------------------------------------------------
import xmlaccess

class Backup_Telnet(QtCore.QThread):
    settingfile = "./setting.xml"
    sig_log=QtCore.pyqtSignal(str)
    xml1=xmlaccess.xml_access(settingfile)

    def __init__(self, parent=None):
        super(Backup_Telnet, self).__init__(parent)
        self.projectname=self.XML_GET(self.xml1,"Project","project_name")
        self.station=self.XML_GET(self.xml1,"Project","project_station")
        self.datefolder=str(datetime.datetime.now().__format__('%d-%m-%Y'))
        self.station_name=socket.gethostname()
        self.ftppth='Logs/'+self.projectname+'/'+self.station+'/'+self.datefolder+'/'+self.station_name
        #if not os.path.isdir(self.ftppth):
            #os.makedirs(self.ftppth)
        self.server_name=self.XML_GET(self.xml1,"Project","Server_IP")
        print ("name: "+ str(self.server_name))
        self.server_user=self.XML_GET(self.xml1,"Project","Server_User")
        print ("user: "+str(self.server_user))
        self.server_psw=self.XML_GET(self.xml1,"Project","Server_password")
        print ("password: "+str(self.server_psw))
        self.isWorking=True

    def XML_GET(self, XMLACESS, MainField, ClienField):
        self.XMLDATA = XMLACESS.xml_com_name(MainField, ClienField)
        for ID in self.XMLDATA:
            self.xmldata = ID.get('name')
            return self.xmldata
    def __del__(self):
        self.isWorking=False
        self.wait()


    def Create_FTP_Folder(self,working_dir):
        try:
            self.ftp_connection.cwd(working_dir) #change work folder,if fail it create folder directly
        except:
            self.ftp_connection.mkd(working_dir)
            self.ftp_connection.cwd(working_dir)

    def Create_FTP_Dir(self,working_dir):
        try:
            folder_list=working_dir.split('/')
            flen=len(folder_list)-1
            idir=folder_list[0]
            for i in range(0,flen):
                idir = folder_list[i]
                self.Create_FTP_Folder(idir)
        except Exception as e:
            print('create_ftp_dir:',e)

    def Upload_File(self,server,user,password,filepath,savepath):
        bResult=False
        try:
            self.ftp_connection=ftplib.FTP(server,user,password)
            self.ftp_connection.set_pasv(False)
            fh=open(filepath,'rb')
            filename=os.path.basename(filepath)
            self.Create_FTP_Dir(savepath)
            if self.ftp_connection.storbinary('STOR '+filename,fh):  #Upload files
                bResult=True
            fh.close()
            return bResult
        except Exception as e:
            print('print ftp:',e)
            return False

    def run(self):
        for file1 in glob.glob('C:\\TMMSeq\\Stat\\Telnet_'+'*.log'):
            if file1 is not None:
                try:
                    self.telnetfile=file1
                    file1=file1[file1.find('Stat\\')+len('Stat\\'):]
                except:
                    pass
                location1="D:\\Telnet_log\\"+str(datetime.datetime.now().__format__('%d-%m-%Y'))
                try:
                    os.makedirs(location1)
                except:
                    pass
                try:
                    self.telnet_backupfile=location1+'\\'+file1
                    self.ftp_telnetfile=self.ftppth+'/'+file1
                    self.Upload_File(self.server_name,self.server_user,self.server_psw,self.telnetfile,
                             self.ftp_telnetfile)

                    shutil.move(self.telnetfile,self.telnet_backupfile)
                except:
                    pass



    def stop(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped = True
        self.terminated = True
#-----------------------------------------------------------------------------------------------------------------------
def consumableread(filename,reference_char):
    with open(filename, 'r') as f:
        textfile_tempa = f.readlines()
        resultindex = textfile_tempa.index(reference_char+"\n") + 1
        testresult = textfile_tempa[resultindex].rstrip("\r\n")
        return  testresult
def consumablelistread(filename):
    with open(filename, 'r') as f:
        textfile_tempa = f.readlines()
        return textfile_tempa
def updateconsumable(filename,infoupdate):
    try:
        with open(filename,'w') as f:
            f.writelines(infoupdate)
    except:
        pass

#------------------------------------------Error code reference---------------------------------------------------------
class Timer_Count(QtCore.QThread):
    def __init__(self, parent=None):
        super(Timer_Count, self).__init__(parent)
        self.starttimer = 0
        self._isRunning  = True
    def run(self):
        while True and self._isRunning == True:
            self.starttimer = self.starttimer+1
            val = self.starttimer
            time.sleep(1)
            self.emit(QtCore.SIGNAL('cycletime'), val)
    def stop(self):
        self._isRunning = False
#-----------------------------------------------------------------------------------------------------------------------
#------------------------------------------Read MD5 Function------------------------------------------------------------
'''def md5Checksum(filePath):
    m = hashlib.md5()
    return m.hexdigest()
'''
#-----------------------------------------------------------------------------------------------------------------------
class ADB(QtCore.QThread):
    def __init__(self, cmd, parent=None):
        super(ADB, self).__init__(parent)
        self.cmd = cmd

    def ADB_RECIVE(self):
        self.command = self.cmd
        try:
            self.p = subprocess.Popen(self.command, shell=True,stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = self.p.communicate()
            print stdout
        except:
            print 'adb read error'

    def STOP(self):
        self.p.kill()
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
class UNLOCK(QtCore.QThread):
    def __init__(self, parent=None):
        super(UNLOCK, self).__init__(parent)

    def ADB_RECIVE(self):
        try:
            os.chdir("E:/dist/")
            self.p = subprocess.Popen("E:/dist/unlock_file.exe", shell=True,stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = self.p.communicate()
            print stdout
        except:
            print 'adb read error'

    def STOP(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
    def exit(self):
        self.p.kill()

class UNLOCK1(QtCore.QThread):
    def __init__(self, parent=None):
        super(UNLOCK1, self).__init__(parent)

    def ADB_RECIVE(self):
        try:
            os.chdir("E:/dist/")
            self.p = subprocess.Popen("E:/dist/unlock_file1.exe", shell=True,stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = self.p.communicate()
            print stdout
        except:
            print 'adb read error'

    def STOP(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
    def exit(self):
        self.p.kill()
class LOCKfpy(QtCore.QThread):
    setting_file = "./setting\\setting.xml"
    xml1 = xmlaccess.xml_access(setting_file)
    def __init__(self, parent=None):
        super(LOCKfpy, self).__init__(parent)
        self.FIX_NAME = socket.gethostname()
        # self.FIX_NAME1='UZW4020BYT'
        # self.STATION='CT'
        self.MODEL_NAME = self.XML_GET(self.xml1, "Project", "project_name")
        self.STATION = self.XML_GET(self.xml1, "Project", "project_station")
    def XML_GET(self, XMLACESS, MainField, ClienField):
        self.XMLDATA = XMLACESS.xml_com_name(MainField, ClienField)
        for ID in self.XMLDATA:
            self.xmldata = ID.get('name')
            return self.xmldata

    def ADB_RECIVE(self):
        try:
            os.chdir("E:/dist/")
            self.p = subprocess.Popen("E:/dist/Load_data_Web_Configv1.exe "+self.MODEL_NAME +" "+self.STATION, shell=True,stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            print self.p
            stdout, stderr = self.p.communicate()
            print stdout
        except:
            print 'adb read error'

    def STOP(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
    def exit(self):
        self.p.kill()