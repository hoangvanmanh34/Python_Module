import socket,hashlib,time,psutil #for sockets
import sys,os,glob,shutil,datetime ,subprocess#for exit
from PyQt4 import QtCore,QtTest
import FTP_Trans
from os import path
from datetime import time
import xmlaccess
class SocketServer(QtCore.QThread):
    def __init__(self,SERVER_IP,SERVER_PORT,parent=None):
        super(SocketServer, self).__init__(parent)
        self.SERVER_IP = SERVER_IP
        self.SERVER_PORT = int(SERVER_PORT)

        try:
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error, msg:
            print 'Failed to create socket. Error code: ' + str(msg[0]) + ' , Error message : '
            sys.exit()
        try:
            self.remote_ip = socket.gethostbyname(self.SERVER_IP)
        except socket.gaierror:
            print 'Hostname could not be resolved. Exiting'
            sys.exit()
        print 'Ip address of ' + self.SERVER_IP + ' is ' +self.remote_ip

    def SERVERConnect(self):
        self.s.connect((self.SERVER_IP,self.SERVER_PORT))
        print 'Socket Connected to ' + self.SERVER_IP + ' on ip ' + self.remote_ip
    def SentToServer(self,cmd):
        try:
            self.s.sendall(cmd)
        except socket.error:
              print 'Send failed'
    def CloseConnection(self):
        self.s.close()
    def run(self):
        while 1:
            val = self.s.recv(8192)
            if (val!=None):
                self.emit(QtCore.SIGNAL('SERVER'),val)

    def stop(self):
        self.s.close()
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
#----------------------------------------------------Analysis Log-------------------------------------------------------
class LogAnalysis(QtCore.QThread):
    setting_file = "./setting\\setting.xml"
    xml1 = xmlaccess.xml_access(setting_file)
    def __init__(self,parent=None):
        super(LogAnalysis, self).__init__(parent)
        self.PC_Name = socket.gethostname()
        self.Model = self.XML_GET(self.xml1, "Project", "project_name")
        self.Station = self.XML_GET(self.xml1, "Project", "project_station")
        self.Log_IP=self.XML_GET(self.xml1,"Project","logIP")
        self.Log_User=self.XML_GET(self.xml1,"Project","log_user")
        self.Log_Password=self.XML_GET(self.xml1,"Project","log_password")

    def XML_GET(self, XMLACESS, MainField, ClienField):
        self.XMLDATA = XMLACESS.xml_com_name(MainField, ClienField)
        for ID in self.XMLDATA:
            self.xmldata = ID.get('name')
            return self.xmldata
    def run(self):
        os.chdir("C:\\Traces")
        while True:
            QtTest.QTest.qWait(5000)
            for file in glob.glob("*.txt"):

                if file is not None:
                    self.logfile = "C:\\Traces\\"+file
                    try:
                        with open(self.logfile, 'r') as f:
                            textfile_temp = f.readlines()
                            self.resultindex = textfile_temp.index("$Result$\n")+1
                            self.md5index = textfile_temp.index("END\n")-1
                            valresult = textfile_temp[self.md5index].rstrip("\r\n")[0:33]
                            self.testresult = textfile_temp[self.resultindex].rstrip("\r\n")

                            if (self.testresult.find("G")!=-1):
                                valresult = valresult+"GOOD"
                                self.emit(QtCore.SIGNAL('Result'), valresult)
                            elif (self.testresult.find("B")!=-1):
                                self.errorcode_index = textfile_temp.index("$Failure_Code$\n")+1
                                valresult =valresult+"_NG_"+textfile_temp[self.errorcode_index].rstrip("\r\n")
                                self.emit(QtCore.SIGNAL('Result'), valresult)
                                print valresult
                            #f.close()
                    except:
                        #f.close()
                        pass
                #----------------Move to backup file--------------------------------------------------------------------
                    datetosave=str(datetime.now().__format__('%d-%B-%Y'))
                    timetosave = str(datetime.now().__format__('%d-%B-%Y_%H-%M-%S'))
                    savedir = 'Logs/' + self.Model + '/' + self.Station + '/' + self.PC_Name + '/' + datetosave  # duong dan server
                    self.location = "D:\\Traces_log\\" + str(datetime.datetime.now().year) + "_" + str(datetime.datetime.now().day) + "_" +str(datetime.datetime.now().month)
                    try:
                        os.makedirs(self.location)
                    except:
                        pass
                    try:
                        self.backupfile = self.location+"\\"+str(file)
                        self.logfile = "C:\\Traces\\" + file
                        if not os.path.isdir(self.logfile):os.mkdir(self.logfile)
                        for i in range(0,2):
                            if os.path.isfile(self.logfile):
                                if not FTP_Trans.Upload_File(self.Log_IP,self.Log_User,self.Log_Password,self.logfile,savedir):
                                    time.sleep(0.5)
                                    if not FTP_Trans.Upload_File(self.Log_IP,self.Log_User,self.Log_Password,self.logfile,savedir):
                                        print ("save log fail")
                                break

                        shutil.move(self.logfile, self.backupfile)
                    except:
                        pass
        os.chdir("C:\\TMMSeq\\Stat")
        while True:
            QtTest.QTest.qWait(500)
            for file in glob.glob("*.log"):
                if file is not None:
                    self.TMMlog="C:\\TMMSeq\\Stat"+file
                    while True:
                        try:
                            bdata = False
                            for proc in psutil.process_iter():
                                # print(proc)
                                if proc.name().upper() == 'TELNET_TELNETEXCHANGES':
                                    bdata = True
                                    break
                                else:
                                    bdata = False
                            if bdata == False:
                                if not os.path.isdir(self.TMMlog): os.mkdir(self.TMMlog)
                                for i in range(0, 2):
                                    if os.path.isfile(self.TMMlog):
                                        if not FTP_Trans.Upload_File(self.Log_IP, self.Log_User, self.Log_Password,
                                                                     self.TMMlog, savedir):
                                            time.sleep(0.5)
                                            if not FTP_Trans.Upload_File(self.Log_IP, self.Log_User,
                                                                         self.Log_Password, self.TMMlog, savedir):
                                                print ("save log fail")
                                        break
                                        src = r"C:\\TMMSeq\\Stat"
                                        dst = r"D:\\TMMSeq"
                                        for root, subdirs, files in os.walk(src):
                                            for file in files:
                                                path = os.path.join(root, file)
                                                shutil.move(path, dst)
                        except Exception as e:
                            print e




    def stop(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
#-----------------------------------------------------------------------------------------------------------------------
def consumableread(filename,reference_char):
    with open(filename, 'r') as f:
        textfile_tempa = f.readlines()
        resultindex = textfile_tempa.index(reference_char+"\n") + 1
        testresult = textfile_tempa[resultindex].rstrip("\r\n")
        return  testresult
def consumablelistread(filename):
    with open(filename, 'r') as f:
        textfile_tempa = f.readlines()
        return textfile_tempa
def updateconsumable(filename,infoupdate):
    try:
        with open(filename,'w') as f:
            f.writelines(infoupdate)
    except:
        pass

#------------------------------------------Error code reference---------------------------------------------------------
class Timer_Count(QtCore.QThread):
    def __init__(self, parent=None):
        super(Timer_Count, self).__init__(parent)
        self.starttimer = 0
        self._isRunning  = True
    def run(self):
        while True and self._isRunning == True:
            self.starttimer = self.starttimer+1
            val = self.starttimer
            time.sleep(1)
            self.emit(QtCore.SIGNAL('cycletime'), val)
    def stop(self):
        self._isRunning = False
#-----------------------------------------------------------------------------------------------------------------------
#------------------------------------------Read MD5 Function------------------------------------------------------------
def md5Checksum(filePath):
    m = hashlib.md5()
    return m.hexdigest()
#-----------------------------------------------------------------------------------------------------------------------
class ADB(QtCore.QThread):
    def __init__(self, cmd, parent=None):
        super(ADB, self).__init__(parent)
        self.cmd = cmd

    def ADB_RECIVE(self):
        self.command = self.cmd
        try:
            self.p = subprocess.Popen(self.command, shell=True,stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = self.p.communicate()
            print stdout
        except:
            print 'adb read error'

    def STOP(self):
        self.p.kill()
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True

class UNLOCK(QtCore.QThread):
    def __init__(self, parent=None):
        super(UNLOCK, self).__init__(parent)

    def ADB_RECIVE(self):
        try:
            os.chdir("E:/dist/")
            self.p = subprocess.Popen("E:/dist/unlock_file.exe", shell=True,stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = self.p.communicate()
            print stdout
        except:
            print 'adb read error'

    def STOP(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
    def exit(self):
        self.p.kill()