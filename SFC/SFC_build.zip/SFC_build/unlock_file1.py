from PyQt4 import QtGui,uic,QtCore,QtTest
import sys,os,system_api
import random
import configparser
from threading import Thread
from os import path
class unlock_window(QtGui.QMainWindow):
    def __init__(self):
        super(unlock_window, self).__init__()
        uic.loadUi('UNLOCK1.ui', self)
        self.lineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.show()
        self.pushButton.clicked.connect(self.ok_button)
        x=random.randint(0,10)
        caculate= "Nhap pw voi x="+str(x)
        #CT=X*2+X*4+X*6; 0; 12;36;48;60;72;84;96;108;120
        #pw: TEonline@#
        #self.label_result.setText("<font color = white ><p align = 'center'>PASS</font>")
        #self.label_result.setStyleSheet("background-color: green")
        self.label_5.setFont(self.font())
        self.label_5.setText(caculate)
        self.errorcode=""
        self.discription=""
        #QtCore.QObject.connect(self.pushButton,QtCore.SIGNAL('click'),self.exit)
    def ok_button(self):
        #mytext = self.textEdit.toPlainText()
        mytext=self.lineEdit.text()
        self.errorcode=str(self.lineEdit_2.text())
        print self.errorcode
        self.description=str(self.lineEdit_3.text())
        print self.description
        readfile = configparser.ConfigParser()
        readfile.read("E:/dist/DATA_FPY.ini")
        a = readfile.get("FPY", "LockFPY")
        if(str(a).find("1"))<0:
            print a
            if(str(mytext).find('TEonline@#0')!=-1) or (str(mytext).find('TEonline@#12')!=-1) or (str(mytext).find('TEonline@#36')!=-1)or (str(mytext).find('TEonline@#48')!=-1)or(str(mytext).find('TEonline@#60')!=-1)\
                or (str(mytext).find('TEonline@#72')!=-1)or (str(mytext).find('TEonline@#84')!=-1)or (str(mytext).find('TEonline@#96')!=-1)or (str(mytext).find('TEonline@#108')!=-1)or (str(mytext).find('TEonline@#120')!=-1):
                if not os.path.isdir('E:/dist'):
                    os.mkdir('E:/dist')
                if os.path.isfile('E:/dist/DATA_FPY.ini'):
                #self.myfile = open('E:/dist/unlock.lk', 'w')
                #self.myfile.write('0')
                #self.myfile.close()
                #u=system_api.API()
                #u.Unlock_FPY()
                    writefile = configparser.ConfigParser()
                    writefile.add_section("FPY")
                    writefile.set("FPY", "LockFPY", "0")
                    writefile.set("FPY", "FPYMode", "0")
                    writefile.set("FPY","ErrorCode",self.errorcode)
                    writefile.set("FPY","Description",self.description)
                    cfgfile = open("E:/dist/DATA_FPY.ini", "w")
                    writefile.write(cfgfile)
                    cfgfile.close()
                self.exit()
        elif (str(a).find("1"))>=0:
            if (str(mytext).find('VnFxcB01#*0') != -1) or (str(mytext).find('VnFxcB01#*12') != -1) or (
                str(mytext).find('VnFxcB01#*36') != -1) or (str(mytext).find('VnFxcB01#*48') != -1) or (
                str(mytext).find('VnFxcB01#*60') != -1) \
                    or (str(mytext).find('VnFxcB01#*72') != -1) or (str(mytext).find('VnFxcB01#*84') != -1) or (
                str(mytext).find('VnFxcB01#*96') != -1) or (str(mytext).find('VnFxcB01#*108') != -1) or (
                str(mytext).find('VnFxcB01#*120') != -1):
                if not os.path.isdir('E:/dist'):
                    os.mkdir('E:/dist')
                if os.path.isfile('E:/dist/DATA_FPY.ini'):
                    # self.myfile = open('E:/dist/unlock.lk', 'w')
                    # self.myfile.write('0')
                    # self.myfile.close()
                    # u=system_api.API()
                    # u.Unlock_FPY()
                    writefile = configparser.ConfigParser()
                    writefile.add_section("FPY")
                    writefile.set("FPY", "LockFPY", "0")
                    writefile.set("FPY", "FPYMode", "0")
                    writefile.set("FPY", "ErrorCode", self.errorcode)
                    writefile.set("FPY", "Description", self.description)
                    cfgfile = open("E:/dist/DATA_FPY.ini", "w")
                    writefile.write(cfgfile)
                    cfgfile.close()
                self.exit()
    def exit(self):
        sys.exit(0)
if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    window = unlock_window()
    #window.setFixedSize(window.width(),window.height())
    sys.exit(app.exec_())
