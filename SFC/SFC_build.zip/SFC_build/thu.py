import sys
from PyQt4 import QtGui
from PyQt4.QtGui import QIcon,QMessageBox
class App(QtGui.QMainWindow):
    def __init__(self):
        super(App,self).__init__()
        #self.title = 'aa'
        #self.left = 10
        #self.top = 30
        #self.width = 320
        #self.height = 200
        #self.initUI()
        #self.setWindowTitle(self.title)
        #self.setGeometry(self.left, self.top, self.width, self.height)
        QMessageBox.warning(self, 'PyQt4 message', "GOI TE ONLINE SUA MAY", QMessageBox.Ok)
        self.show()

        #QMessageBox.warning('goi te')

    '''def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        QMessageBox.warning(self, 'PyQt5 message', "Goi TE sua may", QMessageBox.Ok ,QMessageBox.Ok)
        self.show()
    '''
if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    window = App()
    #window.setFixedSize(window.width(),window.height())
    sys.exit(app.exec_())

