from PyQt4 import QtGui,uic
import sys,os
import random
import configparser
from threading import Thread
from os import path
class unlock_window(QtGui.QMainWindow):
    def __init__(self):
        super(unlock_window, self).__init__()
        uic.loadUi('Form.ui', self)
        #self.lineEdit_6.setEchoMode(QtGui.QLineEdit.Password)
        if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
            readfile = configparser.ConfigParser()
            readfile.read("E:\\dist\\DATA_FPY.ini")
            self.LockMode = readfile.get("FPY", "LockFPY")
            print str(self.LockMode)
            self.errorcode = readfile.get("FPY", "ErrorCode")
            print self.errorcode
            QtGui.QLineEdit(self.errorcode,self.lineEdit_3)
        self.show()
        self.a1=0
        self.pushButton.clicked.connect(self.ok_button)
        #x=random.randint(0,10)
        #caculate= "Nhap pw voi x="+str(x)
        #CT=X*2+X*4+X*6; 0; 12;36;48;60;72;84;96;108;120
        #pw: TEonline@#
        #self.label_result.setText("<font color = white ><p align = 'center'>PASS</font>")
        #self.label_result.setStyleSheet("background-color: green")
        #self.label_5.setFont(self.font())
        #self.label_5.setText(caculate)
        self.errorcode=""
        self.ID=""
        self.Rootcause=""
        self.description=""
        self.Action=""

        '''if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
            readfile = configparser.ConfigParser()
            readfile.read("E:\\dist\\DATA_FPY.ini")
            self.LockMode = readfile.get("FPY", "LockFPY")
            print str(self.LockMode)
            self.errorcode=readfile.get("FPY","ErrorCode")
            self.lineEdit_3.text("")
        '''
        #QtCore.QObject.connect(self.pushButton,QtCore.SIGNAL('click'),self.exit)
    def ok_button(self):

        self.ID=str(self.lineEdit.text())
        print self.ID
        print type(self.ID)
        #self.errorcode=str(self.lineEdit_3.text())
        #self.self.lineEdit_3.append(self.errorcode)
        self.description=str(self.lineEdit_2.text())
        self.Rootcause=str(self.lineEdit_4.text())
        self.Action=str(self.lineEdit_5.text())
        self.lockstatus=str(self.a1)
        if str(self.LockMode).find("1")!=-1 or str(self.LockMode).find("2")!=-1:
            if (str(self.ID).find("V0909464") != -1) or (str(self.ID).find("V0909484") != -1) \
                    or (str(self.ID).find("V0910235") != -1) or (str(self.ID).find("V0911388") != -1) \
                    or (str(self.ID).find("V0915332") != -1) or (str(self.ID).find("V0915332") != -1) \
                    or (str(self.ID).find("V0917902") != -1) or (str(self.ID).find("V0918615") != -1) \
                    or (str(self.ID).find("V0938575") != -1) or (str(self.ID).find("V0940582") != -1) \
                    or (str(self.ID).find("V0957422") != -1) or (str(self.ID).find("V1013911") != -1) \
                    or (str(self.ID).find("V1013913") != -1) or (str(self.ID).find("V1015782") != -1) \
                    or (str(self.ID).find("V1017221") != -1) or (str(self.ID).find("V1034727") != -1) \
                    or (str(self.ID).find("V1036082") != -1) or (str(self.ID).find("V1036096") != -1) \
                    or (str(self.ID).find("V1036097") != -1) or (str(self.ID).find("V3023958") != -1) \
                    or (str(self.ID).find("V3025388") != -1) or (str(self.ID).find("V0500337") != -1) \
                    or (str(self.ID).find("V0902079") != -1) or (str(self.ID).find("V0902117") != -1) \
                    or (str(self.ID).find("V0906544") != -1) or (str(self.ID).find("V0907688") != -1) \
                    or (str(self.ID).find("V0908122") != -1) or (str(self.ID).find("V0908424") != -1) \
                    or (str(self.ID).find("V0908872") != -1) or (str(self.ID).find("V0909145") != -1) \
                    or (str(self.ID).find("V0909146") != -1) or (str(self.ID).find("V0909147") != -1) \
                    or (str(self.ID).find("V0911184") != -1) or (str(self.ID).find("V0911256") != -1) \
                    or (str(self.ID).find("V0911257") != -1) or (str(self.ID).find("V0912127") != -1) \
                    or (str(self.ID).find("V0912611") != -1) or (str(self.ID).find("V0915343") != -1) \
                    or (str(self.ID).find("V0917900") != -1) or (str(self.ID).find("V0928346") != -1) \
                    or (str(self.ID).find("V0933180") != -1) or (str(self.ID).find("V0933711") != -1) \
                    or (str(self.ID).find("V0939870") != -1) or (str(self.ID).find("V0941353") != -1) \
                    or (str(self.ID).find("V0976416") != -1) or (str(self.ID).find("V0981957") != -1) \
                    or (str(self.ID).find("V1020132") != -1) and (str(self.description!="")) and (str(self.Rootcause)!="")and (str(self.Action)!=""):
                if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
                    config = configparser.ConfigParser()
                    config.optionxform = str
                    config.read("E:\\dist\\DATA_FPY.ini")
                    try:
                        config.set("FPY", "IDcard", str(self.ID))
                        config.set("FPY", "LockFPY", str(self.lockstatus))
                        config.set("FPY", "ErrorCode", str(self.errorcode))
                        config.set("FPY", "Description", str(self.description))
                        config.set("FPY", "Rootcause", str(self.Rootcause))
                        config.set("FPY", "Action", str(self.Action))
                        with open("E:\\dist\\DATA_FPY.ini", "w") as configfile:
                            config.write(configfile)
                    except:
                        pass
                self.exit()
    def exit(self):
        sys.exit(0)
if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    window = unlock_window()
    #window.setFixedSize(window.width(),window.height())
    sys.exit(app.exec_())
