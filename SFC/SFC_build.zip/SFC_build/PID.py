from PyQt4 import QtCore
import os,subprocess,testclass1
class ADB_UNLOCK(QtCore.QThread):
    def __init__(self, parent=None):
        super(ADB_UNLOCK, self).__init__(parent)
    def run(self):
        self.pid = testclass1.UNLOCK()
        try:
            self.pid.ADB_RECIVE()
        except:
            pass
        try:
            self.pid.STOP()
        except:
            pass

    def STOP(self):
        try:
            self.pid.exit()
        except:
            pass
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
class ADB_UNLOCK1(QtCore.QThread):
    def __init__(self, parent=None):
        super(ADB_UNLOCK1, self).__init__(parent)
    def run(self):
        self.pid = testclass1.UNLOCK1()
        try:
            self.pid.ADB_RECIVE()
        except:
            pass
        try:
            self.pid.STOP()
        except:
            pass

    def STOP(self):
        try:
            self.pid.exit()
        except:
            pass
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
class ADB_LOCKFPY(QtCore.QThread):
    def __init__(self, parent=None):
        super(ADB_LOCKFPY, self).__init__(parent)
    def run(self):
        self.pid = testclass1.LOCKfpy()
        try:
            self.pid.ADB_RECIVE()
        except:
            pass
        try:
            self.pid.STOP()
        except:
            pass

    def STOP(self):
        try:
            self.pid.exit()
        except:
            pass
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True