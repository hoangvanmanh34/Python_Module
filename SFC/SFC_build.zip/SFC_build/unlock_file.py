from PyQt4 import QtGui,uic,QtCore,QtTest
import sys,os,system_api
import random
import configparser
from threading import Thread
from os import path
class unlock_window(QtGui.QMainWindow):
    def __init__(self):
        super(unlock_window, self).__init__()
        uic.loadUi('UNLOCK.ui', self)
        self.lineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.show()
        self.a1 = 0
        self.pushButton.clicked.connect(self.ok_button)
        x=random.randint(0,10)
        caculate= "Nhap password voi x= "+str(x)
        #CT=X*2+X*4+X*6; 0; 12;36;48;60;72;84;96;108;120
        #pw: TEonline@#
        #self.label_result.setText("<font color = white ><p align = 'center'>PASS</font>")
        #self.label_result.setStyleSheet("background-color: green")
        self.label_5.setFont(self.font())
        self.label_5.setText(caculate)
        self.errorcode=""
        self.discription=""
        if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
            readfile = configparser.ConfigParser()
            readfile.read("E:\\dist\\DATA_FPY.ini")
            self.LockMode = readfile.get("FPY", "LockFPY")
            print str(self.LockMode)
        #QtCore.QObject.connect(self.pushButton,QtCore.SIGNAL('click'),self.exit)
    def ok_button(self):
        #mytext = self.textEdit.toPlainText()
        mytext=self.lineEdit.text()
        #readfile = configparser.ConfigParser()
        #readfile.read("E:/dist/DATA_FPY.ini")
        #a = readfile.get("FPY", "LockFPY")
        self.lockstatus = str(self.a1)
        if str(self.LockMode).find("3") != -1:
            if(str(mytext).find('TEonline@#0')!=-1) or (str(mytext).find('TEonline@#12')!=-1) or (str(mytext).find('TEonline@#36')!=-1)or (str(mytext).find('TEonline@#48')!=-1)or(str(mytext).find('TEonline@#60')!=-1)\
                or (str(mytext).find('TEonline@#72')!=-1)or (str(mytext).find('TEonline@#84')!=-1)or (str(mytext).find('TEonline@#96')!=-1)or (str(mytext).find('TEonline@#108')!=-1)or (str(mytext).find('TEonline@#120')!=-1):
                if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
                    config = configparser.ConfigParser()
                    config.optionxform = str
                    config.read("E:\\dist\\DATA_FPY.ini")
                    try:
                        config.set("FPY", "LockFPY", str(self.lockstatus))
                        with open("E:\\dist\\DATA_FPY.ini", "w") as configfile:
                            config.write(configfile)
                    except:
                        pass
                self.exit()
    def exit(self):
        sys.exit(0)
if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    window = unlock_window()
    #window.setFixedSize(window.width(),window.height())
    sys.exit(app.exec_())
