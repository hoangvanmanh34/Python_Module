import pyautogui
from pyautogui import *

from PyQt4 import QtCore
class Result(QtCore.QThread):
    def __init__(self,testing_image,parent=None):
        super(Result, self).__init__(parent)
        #self.pass_image = pass_image
        #self.fail_image = fail_image
        self.testing_image=testing_image
        self.result = ''

    def run(self):

        while 1:
            try:

                self.pass_list = pyautogui.locateCenterOnScreen(self.testing_image)
                if (self.pass_list is not None):
                    result = "PASS"

                    self.emit(QtCore.SIGNAL('Result'), result)

            except:
                pass
            '''try:

                self.fail_list = pyautogui.screenshotUtil.locateCenterOnScreen(self.fail_image)
                if (self.fail_list is not None):
                    result = "FAIL"
                    self.emit(QtCore.SIGNAL('Result'), result)


            except:
                pass
            '''
    def stop(self):
        self.stopped =True
        self.result=''