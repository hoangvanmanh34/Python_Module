from distutils.core import setup
import py2exe
setup(console=[{"script":'Main.py'}],options ={"py2exe":{"includes":["sip"]}})