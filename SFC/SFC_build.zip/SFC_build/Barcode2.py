
import pyzbar
import numpy as np
import cv2
from PyQt4 import QtCore,QtTest
class Barcode_Read(QtCore.QThread):
    def __init__(self,cam_id,code,length, prefix,file,parent=None):
        super(Barcode_Read, self).__init__(parent)
        self.cam_id = int(cam_id)
        self.code = code

        self.length = length

        self.prefix = prefix

        self.file = file

        self.barcode_old = ""
        self._isRunning = True

    def cam_init(self):
        try:
            self.capture = cv2.VideoCapture(self.cam_id)
            #self.capture.set(3, 640)
            #self.capture.set(3, 480)
            #self.capture.set(cv2.CAP_PROP_BRIGHTNESS, 60)
            #self.capture.set(cv2.CAP_PROP_CONTRAST, 5)
            try:
                cv2.namedWindow('Current', cv2.WINDOW_NORMAL)
            except:
                pass
        except:
            print "Open CAM Issue"
            pass
    def run(self):
        try:
            while self.capture.isOpened():
                #file = open('D:\\brightcam.txt', 'r')
                #cfile = file.read()
                #self.capture.set(cv2.CAP_PROP_BRIGHTNESS, int(cfile))
                #file.close()
                pre_barcode = ''
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                ret, frame = self.capture.read()
                #contrast = 1.25
                #brightness = 100
                #frame[:, :, 2] = np.clip(contrast * frame[:, :, 2] + brightness, 0, 255)
                cv2.imshow('Current', frame)
                decodedObjects = pyzbar.decode(frame)
                for obj in decodedObjects:
                    #(x, y, w, h) = obj.rect

                    (x, y, w, h) = obj.rect
                    frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    barcodeData = obj.data.decode("utf-8")
                    #barcodeData= str(obj.data,'utf-8')
                    barcodeType = obj.type
                    if (str(barcodeType) == self.code):
                        self.barcode= str(barcodeData)
                        if len(self.barcode) == int(self.length):
                            if self.barcode != self.barcode_old:
                                if (self.barcode.find(self.prefix) == 0):
                                    try:
                                        self.f = open(self.file, 'r+')
                                        self.scheck = self.f.readline()
                                        if self.barcode != self.scheck:
                                            self.f.truncate(0)
                                            self.f.writelines(self.barcode)
                                            try:
                                                self.emit(QtCore.SIGNAL('Barcode'), self.barcode)
                                            except:
                                                pass
                                            self.barcode_old = self.barcode
                                        self.f.close()
                                    except:
                                        print "Open read old barcode issue"
                                        pass
                    try:
                        cv2.imshow('Current', frame)
                    except:
                        print "show cam issue"
                        pass
                    QtTest.QTest.qWait(100)
        except Exception as e:
            print ('Current: ', e)
    '''def run(self):
        while True and self._isRunning == True:

            # To quit this program press q.
            """
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            # Breaks down the video into frames"""
            frame = None

            try:
                ret, frame = self.capture.read()
            except:
                pass
            try:
                cv2.imshow('Current', frame)
            except:
                print 'Show cam issue'
                pass
            if (frame is not None):
                self.gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Binary convert before scan
                self.images = Image.fromarray(self.gray)

                self.width, self.height = self.images.size
                self.zbar_image = zbar.Image(self.width, self.height, 'Y800', self.images.tobytes())
            # Scans the zbar setting.b
                self.scanner = zbar.ImageScanner()
                self.scanner.scan(self.zbar_image)
                for decoded in self.zbar_image:
                    if decoded.data is not None:
                        self.bottom_right_correr = [item for item in decoded.location]
                        self.s = self.bottom_right_correr[0]
                        self.x, self.y = self.s[:2]
                        try:
                            frame = cv2.rectangle(frame, (self.x, self.y), (self.x, self.y + 30), (0, 255, 0), 2)
                        except:
                            pass
                        if (str(decoded.type) == self.code):

                            self.barcode = decoded.data
                            if len(self.barcode) == int(self.length):
                                if self.barcode!=self.barcode_old:
                                    if (self.barcode.find(self.prefix) == 0):
                                        try:
                                            self.f = open(self.file, 'r+')
                                            self.scheck = self.f.readline()
                                            if self.barcode != self.scheck:
                                                self.f.truncate(0)
                                                self.f.writelines(self.barcode)
                                                try:
                                                    self.emit(QtCore.SIGNAL('Barcode'), self.barcode)
                                                except:
                                                    pass
                                                self.barcode_old = self.barcode
                                            self.f.close()
                                        except:
                                            print "Open read old barcode issue"
                                            pass
            try:
                cv2.imshow('Current', frame)
            except:
                print "show cam issue"
                pass
            QtTest.QTest.qWait(100)'''

    def stop(self):
        self._isRunning = False
        self.capture.release()
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
        cv2.destroyWindow('Current')


