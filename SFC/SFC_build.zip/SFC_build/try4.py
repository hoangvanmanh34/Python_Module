import testclass1
from PyQt4 import QtGui,uic,QtCore,QtTest
loganalysis = testclass1.LogAnlysis()
loganalysis.start()
QtCore.QObject.connect(loganalysis, QtCore.SIGNAL("Result"), self.TestLogResult)
def TestLogResult(resultvalue):
    print resultvalue

