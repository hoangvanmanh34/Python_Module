import hashlib
from threading import Thread
from PyQt4 import QtGui,uic,QtCore,QtTest
import sys,socket,datetime,pyautogui,os,shutil
import testclass,xmlaccess,Barcode2,PID,system_api,SERIALON,testclass1,checkduplicate,configparser
import os
import glob
import datetime
import ftplib
import FPT_Trans
import time
import pysftp
class SfcWindow(QtGui.QMainWindow):
    third_errorcode = ""
    fail_counter=0
    Test_errorcode = ""
    test_devices1 = 0
    test_devices2 = 0
    test_devices3 = 0
    test_devices4 = 0
    test_devices5 = 0
    setting_file = ".\\setting.xml"
    errorcode_file = ".\\errorcode.xml"
    #setting_file = "./setting\\setting.xml"
    #errorcode_file = "./setting\\errorcode.xml"

    xml1 = xmlaccess.xml_access(setting_file)
    xml2 = xmlaccess.xml_access(errorcode_file)
    location = os.getcwd()
    #tmm = "E:\\Program\\study\\python\\SFC\\dist\\barcode\\TMM.png"
    #sfc = location +"\\barcode\\SFC.png"
    tmm = location + "\\TMM.png"
    stoptmm = location + "\\ABORT.png"
    testing=location+"\\TESTING.png"
    agree1 = location + "\\Agree.png"
    run11 = location + "\\RUN11.png"
    cancel1 = location + "\\CANCEL.png"
    uut = location +"\\UUT.txt"
    labelbitmap = ".\\instruction.png"
    consummable = os.getcwd()+ "\\consumable.txt"
    seqmd5 = ""
    md5 = ""
    hostname = socket.gethostname()
    test_sn = ""
    test_sn1=""
    test_sn2=""
    test_flag = False
    test_flag1 = False
    version_flag = True
    def __init__(self):
        super(SfcWindow,self).__init__()

        uic.loadUi('SFCauto.ui',self)

        #self.statusBar.showMessage("Jennifer Nguyen, Ver: V2.4")
        self.running=False
        #---------------Vaiable get from XML----------------------------------------------------------------------------
        self.monitorserver = self.XML_GET(self.xml1, "ResultServer", "IP")
        self.monitorport = self.XML_GET(self.xml1, "ResultServer", "PORT")
        self.cellid = self.XML_GET(self.xml1, "ResultServer", "CELL_ID")
        self.versionport = self.XML_GET(self.xml1, "VersionSever", "PORT")
        self.versionserver = self.XML_GET(self.xml1, "VersionSever", "IP")

        self.versioncheck = self.XML_GET(self.xml1, "Controlmode", "versionmode")
        self.momitormode = self.XML_GET(self.xml1, "Controlmode", "Resultmode")
        self.Barcode_length = self.XML_GET(self.xml1, "Controlmode", "SNLen")


        self.Barcode_prifix = self.XML_GET(self.xml1, "Barcode", "PRIFIX")
        self.Barcode_code = self.XML_GET(self.xml1, "Barcode", "CODE")

        self.device1 = self.XML_GET(self.xml1, "TestStandard", "devices1")
        self.device2 = self.XML_GET(self.xml1, "TestStandard", "devices2")
        self.device3 = self.XML_GET(self.xml1, "TestStandard", "devices3")
        self.device4 = self.XML_GET(self.xml1, "TestStandard", "devices4")
        #self.device5 = self.XML_GET(self.xml1, "TestStandard", "devices5")

        self.limit1 = int(self.XML_GET(self.xml1, "TestStandard", "target1"))
        self.limit2 = int(self.XML_GET(self.xml1, "TestStandard", "target2"))
        self.limit3 = int(self.XML_GET(self.xml1, "TestStandard", "target3"))
        self.limit4 = int(self.XML_GET(self.xml1, "TestStandard", "target4"))
        #self.limit5 = int(self.XML_GET(self.xml1, "TestStandard", "target5"))

        self.test_devices1 = testclass1.consumableread(self.consummable,"$DEVICES1$")
        self.test_devices2 = testclass1.consumableread(self.consummable, "$DEVICES2$")
        self.test_devices3 = testclass1.consumableread(self.consummable, "$DEVICES3$")
        self.test_devices4 = testclass1.consumableread(self.consummable, "$DEVICES4$")
        #self.test_devices5 = testclass.consumableread(self.consummable, "$DEVICES5$")


        self.project_name = self.XML_GET(self.xml1, "Project", "project_name")
        self.Model=self.project_name
        self.project_station = self.XML_GET(self.xml1, "Project", "project_station")
        self.Station=self.project_station
        self.project_startlen = self.XML_GET(self.xml1, "Project", "project_start")
        self.project_passlen = self.XML_GET(self.xml1, "Project", "project_pass")
        #self.errmd5 = self.XML_GET(self.xml1, "Project", "MD5")
        self.computer_ip = socket.gethostbyname(str(socket.gethostname()))
        self.computer_name = socket.gethostname()
        self.infor = self.computer_name + ";" + self.computer_ip
        self.SFC_SET_MODE = self.XML_GET(self.xml1, "Project", "SFC_MODE")
        self.TMM_SET_MODE=self.XML_GET(self.xml1, "Project", "TMM_MODE")
        #print ("TMMMode:    "+self.TMM_SET_MODE)
        #----------------------Set Devices Name--------------------------------------------------------------------

        self.font = QtGui.QFont()
        self.font.setPointSize(5)
        self.font.setBold(True)
        self.font.setWeight(600)
        self.label_device1.setFont(self.font)
        self.label_device2.setFont(self.font)
        self.label_device3.setFont(self.font)
        self.label_device4.setFont(self.font)
        #self.label_device5.setFont(self.font)
        self.label_device1.setText(self.device1)
        self.label_device2.setText(self.device2)
        self.label_device3.setText(self.device3)
        self.label_device4.setText(self.device4)
        #self.label_device5.setText(self.device5)
        #self.label_device5.setText(self.device5)
        #self.label_device5.setText(self.device5)

        #---------------------------------set to current status lable-------------------------------------------
        self.label_count1.setText(self.test_devices1)
        self.label_count2.setText(self.test_devices2)
        self.label_count3.setText(self.test_devices3)
        self.label_count4.setText(self.test_devices4)
        #self.label_count5.setText(self.test_devices5)
        #pic.setPixmap(QtGui.QPixmap(os.getcwd() + "/logo.png"))

        self.label.setPixmap(QtGui.QPixmap("./setting\\instruction.jpeg"))
        #self.label.show()
        self.test_img = "./" + "\sample\img_testing.png"
        self.noscan=False
        self.dup_flag=""
        #----------------------------------------------------------------------------------------------------------
        self.target1 = self.XML_GET(self.xml1, "TestStandard", "target1")
        self.target2 = self.XML_GET(self.xml1, "TestStandard", "target2")
        self.target3 = self.XML_GET(self.xml1, "TestStandard", "target3")
        self.target4 = self.XML_GET(self.xml1, "TestStandard", "target4")
        self.target5 = self.XML_GET(self.xml1, "TestStandard", "target5")

        #--------------------------Setting in optional------------------------------------------------------------------
        COMlist1 = [self.tr('COM6'), self.tr('COM2'), self.tr('COM3'),
                   self.tr('COM4'), self.tr('COM5'), self.tr('COM1'), self.tr('COM7'), self.tr('COM8')]
        COMlist2 = [self.tr('COM7'), self.tr('COM2'), self.tr('COM3'),
                    self.tr('COM4'), self.tr('COM5'), self.tr('COM6'), self.tr('COM1'), self.tr('COM8')]

        CAMlist = [self.tr('0'), self.tr('1'), self.tr('2'), self.tr('3'), self.tr('4'), self.tr('5')]
        self.comboBoxcam.addItems(CAMlist)
        self.comboBoxtmm.addItems(COMlist1)
        self.comboBoxsfc.addItems(COMlist2)
        self.labelprojectname.setText(self.project_name)
        self.labelstationname.setText(self.project_station)
        self.textEdit_2.append(self.computer_name)
        #Thread(target=self.check_lock_FPY).start()
        Thread(target=self.Check_lock_FPY).start()
        #self.loganalysis = testclass1.LogAnalysis()
        #self.loganalysis.start()
        self.loganalysis = testclass.LogAnalysis()
        self.loganalysis.start()
        #self.checkdup_flag = checkduplicate.Result(self.test_img)
        #self.dup_flag=checkduplicate(self.testing)
        #---------------------------------------------------------------------------------------------------------------
        #self.actionTest_Setting.triggered.connect(self.setting)
        self.actionDebuge.triggered.connect(self.debug)
        self.unnlock.triggered.connect(self.unlock)
        #self.setWindowIcon(QtGui.QIcon("./setting\\icon.png"))
        self.MAIN_ACTION()
        self.statusBar.showMessage("Jennifer Nguyen, Ver: V_12")
        self.show()
    # ----------------------------------------Event Action in Main------------------------------------------------------
    def MAIN_ACTION(self):
        QtCore.QObject.connect(self.pushButtoncamid, QtCore.SIGNAL("clicked()"), self.CAM_Button_Action)
        QtCore.QObject.connect(self.pushButtontmm, QtCore.SIGNAL("clicked()"), self.TMM_Button_Action)
        QtCore.QObject.connect(self.pushButtonsfc, QtCore.SIGNAL("clicked()"), self.SFC_Button_Action)
        QtCore.QObject.connect(self.loganalysis, QtCore.SIGNAL("Result"), self.TestLogResult)
        self.DownloadButton.clicked.connect(self.DownloadTMM)
        print "TMMMode:    " + self.TMM_SET_MODE
#------------------------remove log file--------------------------------------------------------------------------------
        #if not os.path.exists(os.path.dirname("C\\Traces\\")):
        try:
            os.makedirs(os.path.dirname("C:\\Traces\\"))
        except:
            pass

        if os.path.exists("C:\\TMMSeq\\Stat\\Telnet_*.log"):
            try:
                os.remove("C:\\TMMSeq\\Stat\\Telnet_*.log")
            except:
                pass
        #if os.path.exists("C\\Traces\\*.txt"):
            #try:
                #os.remove("C\\Traces\\*.txt")
            #except:
                #pass




        #-----tmm version check--------------------------------------
        self.actionMonitor.triggered.connect(self.MonitorReconnect)
        self.actionVersion.triggered.connect(self.VersionReconnect)
        #-----------------------------------------------------------
        # self.actionDebuge.triggered.connect(self.debug)
        #Thread(target=self.call_lock_FPY).start()
        #----tmm version check-----------------------------------------
        if (self.versioncheck == "ENABLE"):
            self.Versionserver = testclass1.SocketServer(self.versionserver, self.versionport)
            self.Versionserver.SERVERConnect()
            self.Versionserver.start()
            try:
                QtCore.QObject.connect(self.Versionserver, QtCore.SIGNAL("SERVER"), self.Version_check_Action)
                QtTest.QTest.qWait(2000)
            except:
                pass
            self.version_request = self.project_name + self.Loopchar(12 - len(self.project_name)) + self.project_station
            print self.version_request
            self.Versionserver.SentToServer(self.version_request)

        if (self.momitormode == "ENABLE"):
                self.MonitorServer = testclass1.SocketServer(self.monitorserver, self.monitorport)
                self.MonitorServer.SERVERConnect()
                self.MonitorServer.start()

        #self.lfpy = PID.ADB_LOCKFPY()
        #self.lfpy.start()
    #--------------------------------------Set TMMSeq Mode------------------------------------------------
    def SetTMMSeq_Mode(self):
        print "TMMMode:    " + self.TMM_SET_MODE
        if os.path.isfile('C:\\TMMSeq\\Tmmseq.ini'):
            readfile = configparser.ConfigParser()
            readfile.read("C:\\TMMSeq\\Tmmseq.ini")
            TMMMode = readfile.get("SEQ", "R_Mode_Last")
            print ("###########" + str(TMMMode))
            if TMMMode!=str(self.TMM_SET_MODE):
                os.system("wmic process where name='TMMSeq.exe' delete")
                if os.path.isfile('C:\\TMMSeq\\Tmmseq.ini'):
                    config = configparser.ConfigParser()
                    config.optionxform = str
                    config.read('C:\\TMMSeq\\Tmmseq.ini')
                    try:
                        config.set("SEQ", "R_Mode_Last", str(self.TMM_SET_MODE))
                        with open("C:\\TMMSeq\\Tmmseq.ini", "w") as configfile:
                            config.write(configfile)
                    except:
                        pass
                dr = "C:\\TMMSeq\\Sequences\\" + self.Model
                filelist = glob.glob(os.path.join(dr, "*.Seq"))
                for f in filelist:
                    os.startfile(f)
                    QtTest.QTest.qWait(1000)
                    # self.Click1(self.agree1)
                    pyautogui.click(730, 686)
                    QtTest.QTest.qWait(2000)
                    # self.Click2(self.run11)
                    self.TMMSET(self.tmm, "1")
                    QtTest.QTest.qWait(1000)
                    # self.Click3(self.cancel1)
                    pyautogui.click(780, 416)
    #------------------------------------Download TMMSeq---------------------------------------------------------------------
    def DownloadTMM(self):
        if not os.path.exists("C:\\TMMSeq\\Sequences\\" + self.Model):
            os.makedirs("C:\\TMMSeq\\Sequences\\" + self.Model)
        os.system("wmic process where name='TMMSeq.exe' delete")
        dr = "C:\\TMMSeq\\Sequences\\" + self.Model
        print "dir"+dr
        filelist = glob.glob(os.path.join(dr, "*.Seq"))
        for f in filelist:
            os.remove(f)
        Server_IP = "200.168.104.97"
        User = "F1313128"
        Pw = "F1313128"
        Folder = "TE/Danny/SFC_Testprogram/" + self.Model + "/" + self.Station
        Folder1 = "TE/Danny/SFC_Testprogram/" + self.Model + "/" + self.Station + "/"
        Folder_name = "C:/TMMSeq/Sequences/" + self.Model
        filelist = FPT_Trans.File_List(Server_IP, User, Pw, Folder1)
        File_name = filelist[0]
        DTMM = FPT_Trans.Download_File(Server_IP, User, Pw, Folder, Folder_name, File_name)
        if not DTMM:
            print "Download TMM fail"
        else:
            time.sleep(2)
            dr = "C:\\TMMSeq\\Sequences\\" + self.Model
            filelist = glob.glob(os.path.join(dr, "*.Seq"))
            for f in filelist:
                os.startfile(f)
                QtTest.QTest.qWait(1000)
                #self.Click1(self.agree1)
                pyautogui.click(730, 686)
                QtTest.QTest.qWait(2000)
                #self.Click2(self.run11)
                self.TMMSET(self.tmm,"1")
                QtTest.QTest.qWait(1000)
                #self.Click3(self.cancel1)
                '''if (self.Click1(self.cancel1)=="FAIL"):
                    QtTest.QTest.qWait(1000)
                    self.Click1(self.cancel1)
                '''
                pyautogui.click(780, 416)
    #-----------------------------------Define Version check action-----------------------------------------------------
    def Version_check_Action(self,val):
        if (val!=None):
            if (len(val)>33):
                self.seqmd5 = val
                print "TMM Current Version: " + self.seqmd5 + "\r\n"
                self.textEdit.append("TMM Current Version: " + self.seqmd5 + "\r\n")
    #--------------------------check OP---------------------------------------------------------------
    def Check_SN(self):
        while self.running:
            if self.test_sn !=self.test_sn2:
                print ('*******************')
                self.STOPTMM(self.stoptmm)
                #QtTest.QTest.qWait(200)
                #self.STOPTMM(self.stoptmm)
                self.test_flag1 = True
                #self.errorcode='NA000'
                #self.label_result.setText("<font color = white ><p align = 'center'>" + str(self.errorcode) + "</font>")
                break

    #-----------------------------------Reconnect Server----------------------------------------------------------------
    #----------------------------------check LOCK FPY-------------------------------------------------------------------
    def call_lock_FPY(self):
        e = system_api.API()
        while True:
            self.fpy_result = e.Check_lock_FPY()
            if self.fpy_result == 1:
                self.font = QtGui.QFont()
                self.font.setPointSize(14)
                self.label_result.setFont(self.font)
                self.label_result.setText("<font color = white ><p align = 'center'>LOCK FPY!!</font>")
                self.label_result.setStyleSheet("background-color: red")
                # thu.App()
                if not os.path.isdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station):
                    os.mkdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station)
                if os.path.isfile('D:\\Test_Program\\'+ self.Model+"\\"+self.Station+"\\unloc.lk" ):
                    self.myfile = open("D:\\Test_Program\\"+ self.Model+"\\"+self.Station+"\\unloc.lk", 'w')
                    self.myfile.write('0')
                    self.myfile.close()
    def check_lock_FPY(self):
        self.lfpy=PID.ADB_LOCKFPY()
        self.lfpy.start()

    def Check_lock_FPY(self):
        a = "D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\Load_data_Web_Configv1.exe" + " " + self.project_name + " " + self.project_station
        os.chdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station +"\\")
        os.system(a)
    def MonitorReconnect(self):
        try:
            self.MonitorServer.stop()
        except:
            pass
        try:
            if (self.momitormode == "ENABLE"):
                self.MonitorServer = testclass1.SocketServer(self.monitorserver, self.monitorport)
                self.MonitorServer.SERVERConnect()
                self.MonitorServer.start()
        except:
            pass
    def VersionReconnect(self):
        try:
            self.Versionserver.stop()
        except:
            pass
        try:
            if (self.versioncheck == "ENABLE"):
                self.Versionserver = testclass1.SocketServer(self.versionserver, self.versionport)
                self.Versionserver.SERVERConnect()
                self.Versionserver.start()
        except:
            pass


    #------------------------------------Debuge-------------------------------------------------------------------------
    def debug(self):
        #self.MonitorServer.SentToServer("CELL1TEST")
        #self.TMMSET(self.tmm,"a")
       self.version_request = self.project_name + self.Loopchar(12 - len(self.project_name)) + self.project_station
       print self.version_request
       self.Versionserver.SentToServer(self.version_request)
    def unlock(self):
        if not os.path.isdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station):
            os.mkdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station)
        if os.path.isfile("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\DATA_FPY.ini"):
            readfile = configparser.ConfigParser()
            readfile.read("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\DATA_FPY.ini")
            a = readfile.get("FPY", "LockFPY")
            print ("###########"+str(a))
        if (str(a).find("3"))>=0:
            self.unlk = PID.ADB_UNLOCK()
            self.unlk.start()
            self.fail_counter = 0
            self.test_flag = False
            self.test_flag1 = False
            self.version_flag = True
            # self.Versionserver.stop()
            QtTest.QTest.qWait(200)
            # self.loganalysis.stop()
            QtTest.QTest.qWait(200)
            #self.SFC_COM.start()
            try:
                QtCore.QObject.connect(self.SFC_COM, QtCore.SIGNAL("SFC_ACTION"), self.SFC_COM_ACTION)
            except:
                pass
            self.loganalysis = testclass.LogAnalysis()
            self.loganalysis.start()
            try:
                QtCore.QObject.connect(self.loganalysis, QtCore.SIGNAL("Result"), self.TestLogResult)
            except:
                pass
        #self.Versionserver.start()
        elif (str(a).find("1"))>=0 :
            self.unlk = PID.ADB_UNLOCK1()
            self.unlk.start()
            self.fail_counter = 0
            self.test_flag = False
            self.test_flag1 = False
            self.version_flag = True
            # self.Versionserver.stop()
            QtTest.QTest.qWait(200)
            # self.loganalysis.stop()
            QtTest.QTest.qWait(200)
            #self.SFC_COM.start()
            try:
                QtCore.QObject.connect(self.SFC_COM, QtCore.SIGNAL("SFC_ACTION"), self.SFC_COM_ACTION)
            except:
                pass
            self.loganalysis = testclass.LogAnalysis()
            self.loganalysis.start()
            try:
                QtCore.QObject.connect(self.loganalysis, QtCore.SIGNAL("Result"), self.TestLogResult)
            except:
                pass
        elif ((str(a).find("2")) >= 0):
            self.unlk = PID.ADB_UNLOCK1()
            self.unlk.start()
            self.fail_counter = 0
            self.test_flag = False
            self.test_flag1 = False
            self.version_flag = True
            # self.Versionserver.stop()
            QtTest.QTest.qWait(200)
            # self.loganalysis.stop()
            QtTest.QTest.qWait(200)
            self.SFC_COM.start()
            try:
                QtCore.QObject.connect(self.SFC_COM, QtCore.SIGNAL("SFC_ACTION"), self.SFC_COM_ACTION)
            except:
                pass
            self.loganalysis = testclass.LogAnalysis()
            self.loganalysis.start()
            try:
                QtCore.QObject.connect(self.loganalysis, QtCore.SIGNAL("Result"), self.TestLogResult)
            except:
                pass

    #-----------------------------------------cam button action---------------------------------------------------------
    def CAM_Button_Action(self):
        try:
            if(str(self.pushButtoncamid.text()).find("INIT")!= -1):

                self.CAM = Barcode2.Barcode_Read(int(self.comboBoxcam.currentText()),self.Barcode_code,self.Barcode_length,self.Barcode_prifix,self.uut)
                self.CAM.cam_init()
                self.pushButtoncamid.setText("OPEN")
                self.pushButtoncamid.setStyleSheet("background-color: green")
                self.comboBoxcam.setDisabled(True)
                #-----------Start Com-----------------------------------------------------------------------------------
                self.CAM.start()
                #--------------------Connect to cam signal -------------------------------------------------------------
                try:
                    QtCore.QObject.connect(self.CAM, QtCore.SIGNAL("Barcode"), self.Barcode_ACTION)
                except:
                    pass
            elif(str(self.pushButtoncamid.text()).find("OPEN")!= -1):
                try:
                    QtCore.QObject.disconnect(self.CAM, QtCore.SIGNAL("Barcode"), self.Barcode_ACTION)
                except:
                    pass
                self.CAM.stop()
                self.pushButtoncamid.setText("INIT")
                self.pushButtoncamid.setStyleSheet("background-color: red")
                self.comboBoxcam.setDisabled(False)
        except:
            pass

    #-------------------------------------------------Barcode reciver action -------------------------------------------
    def Barcode_ACTION(self, barcode):
        #--------------Check TMMSeq run or not---------------------------------------------------------

        self.SetTMMSeq_Mode()
        #os.startfile("C:\\TMMSeq\\Install\\RedRatX\\RedRatHub-V4.28\\RedRatHub.bat")

        if os.path.exists("C:\\TMMSeq\\Stat\\Telnet_*.log"):
            try:
                os.remove("C:\\TMMSeq\\Stat\\Telnet_*.log")
            except:
                pass
        if os.path.exists("D:\\Snap\\" + str(datetime.datetime.now())):
            try:
                os.makedirs("D:\\Snap\\" + str(datetime.datetime.now()))
            except:
                pass
        self.test_sn=""
        self.loganalysis = testclass.LogAnalysis()
        self.loganalysis.start()

        #f = open('E:/dist/DATA_FPY.ini', 'r')
        #contents = f.read()
        #if (str(contents).find('0') >= 0):
            # thread check FPY server and check lock
            #a = system_api.API()
            #self.b = a.Top_three_Errocode()
            #c=''.join(map(str, self.b))
            #self.textEdit_2.append(c)
            #self.textEdit_2.append(''.join(map(str, self.b)))
            #Thread(target=a.Check_lock_FPY).start()
            # -------------------------------check duplicate SN-----------------
            #self.dup_flag=self.checkduplicate.start()
            #self.dup_flag.start()
            #print self.dup_flag
            #if self.checkduplicate(self.testing) is None:
            #----------------------------------------------------------------------
        if not os.path.isfile(
                'C:\\LitePoint\\IQfact_plus\\Realtek 8822 3.3.0.Eng25_Lock\\Bin\\Log\\Log_all.txt'):
            print ('**********************')

        else:
            os.remove(
                    'C:\\LitePoint\\IQfact_plus\\Realtek 8822 3.3.0.Eng25_Lock\\Bin\\Log\\Log_all.txt')
        readfile=configparser.ConfigParser()
        readfile.read("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\DATA_FPY.ini")
        a=readfile.get("FPY","LockFPY")
        if (str(a).find('0'))>=0:
            if (len(barcode) == int(self.Barcode_length)) and (barcode != None) :
                print  "barcode"+barcode
                self.test_sn = barcode

                QtTest.QTest.qWait(200)
                self.SFC_COM.SERIAL_WRITE(self.test_sn)

                self.SFCLogbackup()
                self.textEdit.setText("")
                self.textEdit.append(
                    "-----------------------------------------------------------------------------------\r\n")
                self.textEdit.append(str(datetime.datetime.now()) + "Set SN to Test: " + self.test_sn + "\r\n")
            #if (len(barcode) == int(self.Barcode_length)) and (barcode != None) and (self.noscan == True):
            '''if self.dup_flag=="FAIL":
            #else:
                try:
                    self.SFC_COM.stop()
                    self.SFC_COM.SERIAL_CLOSE()
                    self.pushButtonsfc.setText("DISABLE")
                    self.pushButtonsfc.setStyleSheet("background-color: red")
                    self.comboBoxsfc.setDisabled(False)
                    self.TMM_COM.stop()
                    self.TMM_COM.SERIAL_CLOSE()
                    self.pushButtontmm.setText("DISABLE")
                    self.pushButtontmm.setStyleSheet("background-color: red")
                    self.comboBoxsfc.setDisabled(False)
                except:
                    pass
                self.STOPTMM(self.stoptmm)
            '''
            if (barcode != None) and (self.device1.find("NA") == -1):
                self.test_devices1 = int(self.test_devices1) + 1
                self.label_count1.setText(str(self.test_devices1))
            if (barcode != None) and (self.device2.find("NA") == -1):
                self.test_devices2 = int(self.test_devices2) + 1
                self.label_count2.setText(str(self.test_devices2))
            if (barcode != None) and (self.device3.find("NA") == -1):
                self.test_devices3 = int(self.test_devices3) + 1
                self.label_count3.setText(str(self.test_devices3))
            if (barcode != None) and (self.device4.find("NA") == -1):
                self.test_devices4 = int(self.test_devices4) + 1
                self.label_count4.setText(str(self.test_devices4))
            #if (barcode != None) and (self.device5.find("NA") == -1):
                #self.test_devices5 = int(self.test_devices5) + 1
                #self.label_count5.setText(str(self.test_devices5))
            if (int(self.test_devices1) > int(self.target1)) or (int(self.test_devices2) > int(self.target2)) or (
                        int(self.test_devices3) > int(self.target3)) or int(self.test_devices4)> int(self.target4)\
                    :
                self.SFC_COM.SERIAL_CLOSE()
                self.TMM_COM.SERIAL_CLOSE()

                self.loginfo = "Consumer need to change\n"
                self.textEdit.append(self.loginfo)
                if (self.momitormode == 'ENABLE'):
                    self.MonitorServer.SentToServer(self.loginfo)
                    # -- -------------------------------------------------------------------------------------------------------------
                    # -------------------Read current consummable status-------------------------------------------------------------
            try:
                self.statuslist = testclass1.consumablelistread(self.consummable)
            except:
                pass
            self.statuslist[2] = str(self.test_devices1) + "\n"
            self.statuslist[4] = str(self.test_devices2) + "\n"
            self.statuslist[6] = str(self.test_devices3) + "\n"
            self.statuslist[8] = str(self.test_devices4) + "\n"
            # self.statuslist[10] = str(self.test_devices5) + "\n"
            # --------------------Update comsummable to file-----------------------------------------------------------------
            try:
                testclass1.updateconsumable(self.consummable, self.statuslist)
            except:
                print "can not update consumer"
                pass
            #else:
                #self.STOPTMM(self.stoptmm)
                #self.label_result.setText("<font color = white ><p align = 'center'>ID002</font>")
                #self.SFC_COM.stop()
                #self.SFC_COM.SERIAL_CLOSE()
                #self.pushButtonsfc.setText("DISABLE")
                #self.pushButtonsfc.setStyleSheet("background-color: red")
                #self.comboBoxsfc.setDisabled(False)

        elif (str(a).find('1') >= 0):
            try:
                #self.lfpy.stopped()
                self.SFC_COM.stop()
                self.SFC_COM.SERIAL_CLOSE()
                self.pushButtonsfc.setText("DISABLE")
                self.pushButtonsfc.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)
                self.TMM_COM.stop()
                self.TMM_COM.SERIAL_CLOSE()
                self.pushButtontmm.setText("DISABLE")
                self.pushButtontmm.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)
            except:
                pass
            #self.STOPTMM(self.stoptmm)
            self.font = QtGui.QFont()
            self.font.setPointSize(14)
            self.label_result.setFont(self.font)
            self.label_result.setText("<font color = white ><p align = 'center'>LOCKLEADER</font>")
            self.label_result.setStyleSheet("background-color: red")
        elif (str(a).find('2') >= 0):
            try:
                self.SFC_COM.stop()
                self.SFC_COM.SERIAL_CLOSE()
                self.pushButtonsfc.setText("DISABLE")
                self.pushButtonsfc.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)
                self.TMM_COM.stop()
                self.TMM_COM.SERIAL_CLOSE()
                self.pushButtontmm.setText("DISABLE")
                self.pushButtontmm.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)
            except:
                pass
            # self.STOPTMM(self.stoptmm)
            self.font = QtGui.QFont()
            self.font.setPointSize(14)
            self.label_result.setFont(self.font)
            self.label_result.setText("<font color = white ><p align = 'center'>LOCK3</font>")
            self.label_result.setStyleSheet("background-color: red")
        elif (str(a).find('3') >= 0):
            try:
                self.SFC_COM.stop()
                self.SFC_COM.SERIAL_CLOSE()
                self.pushButtonsfc.setText("DISABLE")
                self.pushButtonsfc.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)
                self.TMM_COM.stop()
                self.TMM_COM.SERIAL_CLOSE()
                self.pushButtontmm.setText("DISABLE")
                self.pushButtontmm.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)
            except:
                pass
            # self.STOPTMM(self.stoptmm)
            self.font = QtGui.QFont()
            self.font.setPointSize(14)
            self.label_result.setFont(self.font)
            self.label_result.setText("<font color = white ><p align = 'center'>LOCK3TIMES</font>")
            self.label_result.setStyleSheet("background-color: red")
                # -------------------------------------------------------------------------------------------------------------------

    def TMM_Button_Action(self):
        try:
            if (str(self.pushButtontmm.text()).find("DISABLE") != -1):
                self.TMM_COM = SERIALON.SERIAL_OB(str(self.comboBoxtmm.currentText()), "TMM")
                self.TMM_COM.SERIAL_OPEN()
                self.pushButtontmm.setText("ENABLE")
                self.pushButtontmm.setStyleSheet("background-color: green")
                self.comboBoxtmm.setDisabled(True)
                # ------------Start SFC Com-----------------------------------------------------------------------------
                self.TMM_COM.start()
                try:
                    QtCore.QObject.connect(self.TMM_COM, QtCore.SIGNAL("TMM_ACTION"), self.TMM_COM_ACTION)
                except:
                    pass
            elif (str(self.pushButtontmm.text()).find("ENABLE") != -1):
                self.TMM_COM.stop()
                self.TMM_COM.SERIAL_CLOSE()
                self.pushButtontmm.setText("DISABLE")
                self.pushButtontmm.setStyleSheet("background-color: red")
                self.comboBoxtmm.setDisabled(False)
        except:
            print "can not open "
    #----------------------------------Define TMM Reciver infomation ---------------------------------------------------
    def TMM_COM_ACTION(self,TMM_BUFF):
        self.test_flag = False
        try:

            TMM_BUFF = str(TMM_BUFF).rstrip("\n")
            TMM_BUFF = str(TMM_BUFF).rstrip("\r")

        except:
            pass
        if (len(TMM_BUFF) == int(self.project_passlen)):

            self.textEdit.append(
                "TMM Update Data To Database: " + TMM_BUFF + " with length = " + str(len(TMM_BUFF)) + "\r\n")
        else:
            self.textEdit.append(
                "TMM Update Wrong Length to Database: " + TMM_BUFF + " with length = " + str(len(TMM_BUFF)) + "\r\n")
        self.SFC_COM.SERIAL_WRITE(TMM_BUFF)
        #TMM_BUFF = str(TMM_BUFF).rstrip("\r\n")
        #if (len(TMM_BUFF)==int(self.project_passlen)):
            #self.test_sn1=TMM_BUFF[0:int(self.Barcode_length)]
            #print ("11111111"+self.test_sn1)
            #self.SFC_COM.SERIAL_WRITE(TMM_BUFF)
            #self.SFC_COM.SERIAL_WRITE(TMM_BUFF)
            #self.SFC_COM.SERIAL_WRITE(TMM_BUFF)\
            #QtTest.QTest.qWait(1000)
            #self.SFC_COM.SERIAL_WRITE(TMM_BUFF)

            #self.textEdit.append("TMM Update Wrong Length to Database: " + TMM_BUFF + " with length = " + str(len(TMM_BUFF)) + "\r\n")

            #-------check scanA test B----------------------------


    #-------------------------------------------------------------------------------------------------------------------


    def SFC_Button_Action(self):
        try:
            if (str(self.pushButtonsfc.text()).find("DISABLE") != -1):
                self.SFC_COM = SERIALON.SERIAL_OB(str(self.comboBoxsfc.currentText()), "SFC")
                self.SFC_COM.SERIAL_OPEN()
                self.pushButtonsfc.setText("ENABLE")
                self.pushButtonsfc.setStyleSheet("background-color: green")
                self.comboBoxsfc.setDisabled(True)
                # ------------Start SFC Com-----------------------------------------------------------------------------
                self.SFC_COM.start()
                try:
                    QtCore.QObject.connect(self.SFC_COM, QtCore.SIGNAL("SFC_ACTION"), self.SFC_COM_ACTION)
                except:
                    pass

            elif (str(self.pushButtonsfc.text()).find("ENABLE") != -1):
                self.SFC_COM.stop()
                self.SFC_COM.SERIAL_CLOSE()
                self.pushButtonsfc.setText("DISABLE")
                self.pushButtonsfc.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)

        except:
            print "can not open "
    #------------------------------------Define SFC com reciver infomation ---------------------------------------------
    def SFC_COM_ACTION(self, SFC_BUFF):
        if not self.running:
            self.running = True
        SFC_BUFF = str(SFC_BUFF).rstrip("\r\n")
        if (len(SFC_BUFF)== int(self.project_startlen)+4) and (str(SFC_BUFF).find("PASS")!=-1):
            #self.STOPTMM(self.stoptmm)
            QtTest.QTest.qWait(300)
            #if(self.test_flag1==False):
            # click abort
            if (self.TMMSET(self.tmm, self.test_sn) == "FAIL"):
                QtTest.QTest.qWait(200)
                self.STOPTMM(self.stoptmm)
            #self.TMMSET(self.tmm,self.test_sn)
            #else:
                #self.test_flag1=False
                #self.STOPTMM(self.stoptmm)
            self.test_sn2=SFC_BUFF[0:int(self.Barcode_length)]
            print ("SN is: "+self.test_sn2)
            #Thread(target=self.Check_SN).start()
            #pyautogui.typewrite(self.test_sn+'\n')
            '''self.STOPTMM(self.stoptmm)
                self.errorcode = 'NA000'
                self.label_result.setText("<font color = white ><p align = 'center'>" + str(self.errorcode) + "</font>")
                self.label_result.setStyleSheet("background-color: red")
                if not os.path.isdir('E:/dist'):
                    os.mkdir('E:/dist')
                if os.path.isfile('E:/dist/unlock.lk'):
                    self.myfile = open('E:/dist/unlock.lk', 'w')
                    self.myfile.write('0')
                    self.myfile.close()
                    # /lock1
                try:
                    self.SFC_COM.stop()
                    self.SFC_COM.SERIAL_CLOSE()
                    self.pushButtonsfc.setText("DISABLE")
                    self.pushButtonsfc.setStyleSheet("background-color: red")
                    self.comboBoxsfc.setDisabled(False)
                    self.TMM_COM.stop()
                    self.TMM_COM.SERIAL_CLOSE()
                    self.pushButtontmm.setText("DISABLE")
                    self.pushButtontmm.setStyleSheet("background-color: red")
                    self.comboBoxsfc.setDisabled(False)

                except:
                    pass
                '''
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            QtTest.QTest.qWait(200)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            QtTest.QTest.qWait(200)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            QtTest.QTest.qWait(200)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            QtTest.QTest.qWait(200)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)

            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            #QtTest.QTest.qWait(2000)
            #self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            self.loginfo = "SFC Feedback To Start Test: " + SFC_BUFF + " with length " + str(len(SFC_BUFF)) + "\r\n"
            self.textEdit.append(self.loginfo)
            self.font = QtGui.QFont()
            self.font.setPointSize(12)
            self.font.setBold(True)
            self.font.setWeight(600)
            self.label_result.setFont(self.font)
            self.label_result.setText("<font color = blue ><p align = 'center'>TESTING</font>")
            self.label_result.setStyleSheet("background-color: yellow")
            if (self.momitormode == "ENABLE"):
                self.loginfo = str(self.cellid) + "TEST" + self.loginfo
                self.MonitorServer.SentToServer(self.loginfo)
                #--------------------check abc  -----------------------------------------------------------------------------
            #-----------------------------------------------------------------------------------------------------------

        elif(len(SFC_BUFF)==int(self.project_passlen)+4) and (SFC_BUFF.find("PASS")!=-1):
            SFC_BUFF = str(SFC_BUFF).rstrip('\r\n')
            #self.test_sn2 = SFC_BUFF[0:int(self.Barcode_length)]
            #print ("22222222222" + self.test_sn2)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            QtTest.QTest.qWait(200)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            QtTest.QTest.qWait(200)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            QtTest.QTest.qWait(200)
            self.TMM_COM.SERIAL_WRITE(SFC_BUFF)
            self.loginfo = "SFC Confirm Update Database: "+SFC_BUFF+" with length "+ str(len(SFC_BUFF))+"\r\n"
            self.textEdit.append(self.loginfo)
            self.textEdit.append("--------------------------------------End-------------------------------------------\r\n")
            self.SFCLogbackup()
            #self.Save_log()

            #self.saveLog(self.test_sn)
            if self.version_flag == True:
                self.font = QtGui.QFont()
                self.font.setPointSize(12)
                self.font.setBold(True)
                self.font.setWeight(600)
                self.label_result.setFont(self.font)
                self.label_result.setText("<font color = white ><p align = 'center'>PASS</font>")
                self.label_result.setStyleSheet("background-color: green")
                if (self.momitormode == "ENABLE"):
                    self.loginfo = str(self.cellid)+"PASS"+self.loginfo
                    self.MonitorServer.SentToServer(self.loginfo)
        else:
            self.textEdit.append("SFC Confirm Wrong Database: " + SFC_BUFF + " with length " + str(len(SFC_BUFF)) + "\r\n")
    # -------------------XML ACCESSS TO INIT GUI------------------------------------------------------------------------
    def XML_GET(self, XMLACESS, MainField, ClienField):
        self.XMLDATA = XMLACESS.xml_com_name(MainField, ClienField)
        for ID in self.XMLDATA:
            self.xmldata = ID.get('name')
            return self.xmldata
    #------------------------------------Debuge-------------------------------------------------------------------------
    #--------------------Log Analysis Result----------------------------------------------------------------------------
    def TestLogResult(self,valresult):
        os.system("wmic process where name='RedRatHubCmd.exe' delete")
        print valresult
        print('chuan bi luu log day')
        self.Save_log()
        if (valresult.find("_NG_")!=-1):
            self.test_flag = False
            self.tcherrorcode = str(valresult[38:]).replace("\t","")
            self.tcherrorcode=self.tcherrorcode.replace(" ","")
            self.tcherrorcode=self.tcherrorcode.replace("!","")
            self.tcherrorcode=self.tcherrorcode.replace("@","")
            self.tcherrorcode=self.tcherrorcode.replace("#","")
            self.tcherrorcode=self.tcherrorcode.replace("$","")
            self.tcherrorcode=self.tcherrorcode.replace("%","")
            self.tcherrorcode=self.tcherrorcode.replace("^", "")
            self.tcherrorcode=self.tcherrorcode.replace("&", "")
            self.tcherrorcode=self.tcherrorcode.replace("*", "")
            #-----------------------3times fail ------------------------------------------------------------------------
            #if ((self.tcherrorcode == self.third_errorcode) and (self.tcherrorcode.find('ID000')<=0) and (self.tcherrorcode.find('ID005')<=0)):
                #self.fail_counter = self.fail_counter +1

#-----------------------------------------------------------------------------------------------------------
#------ add recall TMMSeq for model DSI724BIS------------------------------------------
        #if (valresult.find("_NG_")!=-1 and (valresult.find("ErrorcodeA")!=-1) and (valresult.find("ErrorodeB")!=-1)):
            #self.DownloadTMM()
#=-----------------------------------------------------
            '''self.tcherrorcode.replace(" ","")
            self.tcherrorcode.replace("!", "")
            self.tcherrorcode.replace("@", "")
            self.tcherrorcode.replace("#", "")
            self.tcherrorcode.replace("$", "")
            self.tcherrorcode.replace("%", "")
            self.tcherrorcode.replace("^", "")
            self.tcherrorcode.replace("&", "")
            self.tcherrorcode.replace("*", "")

            self.tcherrorcode.replace("0", "_0")
            self.tcherrorcode.replace("1", "_1")
            self.tcherrorcode.replace("2", "_2")
            self.tcherrorcode.replace("3", "_3")
            self.tcherrorcode.replace("4", "_4")
            self.tcherrorcode.replace("5", "_5")
            self.tcherrorcode.replace("6", "_6")
            self.tcherrorcode.replace("7", "_7")
            self.tcherrorcode.replace("8", "_8")
            self.tcherrorcode.replace("9", "_9")
            '''
            self.errorcode = self.XML_GET(self.xml2, "ERRORCODE",self.tcherrorcode)
            #self.third_errorcode=self.errorcode
            if (self.third_errorcode == self.errorcode):
                self.fail_counter = self.fail_counter + 1
                #print ("############"+self.fail_counter)
                print self.fail_counter
            else:
                self.fail_counter=0
                self.third_errorcode=self.errorcode
            if (self.errorcode == None):
                self.errorcode = "ID002"
            if (self.fail_counter == 3):
                self.loginfo = "TMM STOP FOR 3 TIMES  FAIL SAME ERROR CODE: \r\n"
                self.textEdit.append(self.loginfo)
                self.font = QtGui.QFont()
                self.font.setPointSize(15)
                self.font.setBold(True)
                self.font.setWeight(600)
                self.label_result.setFont(self.font)
                self.label_result.setText("<font color = white ><p align = 'center'> LOCK!! </font>")
                self.label_result.setStyleSheet("background-color: red")
                self.fail_counter=0
                # thu.App()
                if not os.path.isdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\DATA_FPY.ini"):
                    os.mkdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station)
                if os.path.isfile("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\DATA_FPY.ini"):
                    #self.myfile = open('E:/dist/unlock.lk', 'w')
                    #self.myfile.write('0')
                    #self.myfile.close()
                    writefile = configparser.ConfigParser()
                    writefile.add_section("FPY")
                    writefile.set("FPY", "LockFPY", "3")
                    cfgfile = open("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\DATA_FPY.ini", "w")
                    writefile.write(cfgfile)
                    cfgfile.close()
                # /lock1
                try:
                    self.SFC_COM.stop()
                    self.SFC_COM.SERIAL_CLOSE()
                    self.pushButtonsfc.setText("DISABLE")
                    self.pushButtonsfc.setStyleSheet("background-color: red")
                    self.comboBoxsfc.setDisabled(False)
                    self.TMM_COM.stop()
                    self.TMM_COM.SERIAL_CLOSE()
                    self.pushButtontmm.setText("DISABLE")
                    self.pushButtontmm.setStyleSheet("background-color: red")
                    self.comboBoxsfc.setDisabled(False)

                except:
                    pass

                '''try:
                    QtCore.QObject.disconnect(self.CAM, QtCore.SIGNAL("Barcode"), self.Barcode_ACTION)
                except:
                    pass
                self.CAM.stop()
                '''
            else:
                self.font = QtGui.QFont()
                self.font.setPointSize(12)
                self.font.setBold(True)
                self.font.setWeight(600)
                self.label_result.setFont(self.font)
                self.label_result.setText("<font color = white ><p align = 'center'>" + str(self.errorcode) + "</font>")
                self.label_result.setStyleSheet("background-color: red")
                # -------------------------Update To Database----------------------------------------------------------------
                self.failupdate = self.test_sn + self.Loopchar(
                    int(self.project_passlen) - len(self.test_sn) - 12) + self.hostname + self.errorcode
                self.SFC_COM.SERIAL_WRITE(self.failupdate)
                self.loginfo = "TMM Update FAIL To Database: " + self.failupdate + "\r\n"
                self.textEdit.append(self.loginfo)
                self.textEdit.append(
                    "--------------------------------------End-------------------------------------------\r\n")
                self.SFCLogbackup()
                #self.saveLog(self.test_sn)
                #self.saveLogTelnet()

                #self.Save_log()
            if (self.momitormode == "ENABLE"):
                self.loginfo = str(self.cellid)+"FAIL"+self.loginfo
                self.MonitorServer.SentToServer(self.loginfo)

            #------------------------------------------------------------------------------ -----------------------------

        if (self.versioncheck.find("ENABLE")!=-1):
            #self.seqmd5 = str(self.seqmd5[18:51]).rstrip("\r\n").replace(" ","")
            self.logmd5 = str(valresult[0:33]).rstrip("\r\n").replace(" ","" )
            self.logmd5 = self.logmd5[-32:]

            print "Standard Seq MD5:"+self.seqmd5
            print "Read Log Seq MD5:"+self.logmd5
            if len(self.logmd5)==32:
                print "Check Matching" + str(self.logmd5.find(self.seqmd5))
                if (self.seqmd5.find(self.logmd5) == -1):
                    print "Close Serial because wrong seq"
                    try:
                        self.SFC_COM.stop()
                        self.SFC_COM.SERIAL_CLOSE()
                        self.pushButtonsfc.setText("DISABLE")
                        self.pushButtonsfc.setStyleSheet("background-color: red")
                        self.comboBoxsfc.setDisabled(False)

                    except:
                        pass
                    self.version_flag = False
                    self.font = QtGui.QFont()
                    self.font.setPointSize(10)
                    self.font.setBold(True)
                    self.font.setWeight(600)
                    self.label_result.setFont(self.font)
                    self.label_result.setText("<font color = white ><p align = 'center'>WRONG SEQ</font>")
                    self.label_result.setStyleSheet("background-color: red")
                    #thu.App()
                    if not os.path.isdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station):
                        os.mkdir("D:\\Test_Program\\"+self.Model+"\\"+self.Station)
                    if os.path.isfile("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\unlock.lk"):
                        self.myfile = open("D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\unlock.lk", 'w')
                        self.myfile.write('0')
                        self.myfile.close()

                    # /lock1
                    try:
                        self.SFC_COM.stop()
                        self.SFC_COM.SERIAL_CLOSE()
                        self.pushButtonsfc.setText("DISABLE")
                        self.pushButtonsfc.setStyleSheet("background-color: red")
                        self.comboBoxsfc.setDisabled(False)
                        self.TMM_COM.stop()
                        self.TMM_COM.SERIAL_CLOSE()
                        self.pushButtontmm.setText("DISABLE")
                        self.pushButtontmm.setStyleSheet("background-color: red")
                        self.comboBoxsfc.setDisabled(False)

                    except:
                        pass

                    self.loginfo = str(self.cellid) + "WRONG SEQ"
                    if (self.momitormode == "ENABLE"):
                        self.loginfo = str(self.cellid) + "FAIL" + self.loginfo
                        self.MonitorServer.SentToServer(self.loginfo)
        '''self.md5 = hashlib.md5(self.errorcode_file)
        if (str(self.md5)) != str(self.errmd5):
            try:
                self.SFC_COM.stop()
                self.SFC_COM.SERIAL_CLOSE()
                self.pushButtonsfc.setText("DISABLE")
                self.pushButtonsfc.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)
                self.TMM_COM.stop()
                self.TMM_COM.SERIAL_CLOSE()
                self.pushButtontmm.setText("DISABLE")
                self.pushButtontmm.setStyleSheet("background-color: red")
                self.comboBoxsfc.setDisabled(False)

            except:
                pass
        '''
    #----------------------------------Start TMM sequence test--------------------------------------------
    def Click1(self,image):
        self.list2=pyautogui.locateCenterOnScreen(image,confidence=0.9)
        print self.list2
        pyautogui.click(self.list2)
        if (self.list2 == None):
            return "FAIL"
    def Click2(self,image,data):
        self.list3=pyautogui.locateCenterOnScreen(image,confidence=0.9)
        print self.list3
        pyautogui.click(self.list3)
        self.dat=data+"\r\n"
        QtTest.QTest.qWait(500)
        pyautogui.typewrite(self.dat)
    def Click3(self,image):
        self.list4=pyautogui.locateCenterOnScreen(image,confidence=0.9)
        print self.list4
        pyautogui.click(self.list4)
    #--------------------------------------Common Using function--------------------------------------------------------
    def TMMSET(self, image, data):
        self.list1 = pyautogui.locateCenterOnScreen(image, confidence=0.9)
        print self.list1
        pyautogui.click(self.list1)
        self.dat = data + '\r\n'
        QtTest.QTest.qWait(500)
        pyautogui.typewrite(self.dat)
        if (self.list1 == None):
            return "FAIL"

    def SFCSET(self, image, data):
        try:

            #self.list1 = pyautogui.screenshotUtil.locateCenterOnScreen(image)
            self.list1=pyautogui.locateCenterOnScreen(image)
            print (self.list1)
            pyautogui.click(self.list1)
            self.dat = data + '\r\n'
            QtTest.QTest.qWait(50)
            pyautogui.typewrite(self.dat)
        except:
            print 'SFC data set issues'
            pass
    def STOPTMM(self,image):
        self.abortbtn = pyautogui.locateCenterOnScreen(image)
        #location_abortbtn=pyautogui.center(self.abortbtn)
        pyautogui.click(self.abortbtn)
        #print self.list2

    def checkduplicate(self,image):
        self.testing_img=pyautogui.locateOnScreen(image)
    def Loopchar(self,loopnumber):
        self.s = ""
        for i in range(loopnumber):
            self.s = self.s+" "
        return self.s
    def SFCLogbackup(self):
        self.location = "D:\\SFC_log\\" + str(datetime.datetime.now().year) + "_" + str(
        datetime.datetime.now().day) + "_" + str(datetime.datetime.now().month)
        try:
            os.makedirs(self.location)
        except:
            pass
            self.SFC_file = self.location+"\\SFC.txt"
        try:
            with open(self.SFC_file,'a') as logfile:
                logfile.write(str(self.textEdit.toPlainText()))
            QtTest.QTest.qWait(1000)
            logfile.close()
        except:
            pass

    def saveLog(self, file_name):
        testdate = datetime.datetime.now()
        datelogtest = str(testdate.year) + '_' + str(testdate.month) + '_' + str(testdate.day) + '_' + str(testdate.hour) + '_' + str(testdate.minute) + '_' + str(testdate.second)
        try:
            self.backupfile = "D:\\Log_Lite_point\\UZW4026ELE\\" + str(datetime.datetime.now().__format__('%d-%m-%Y'))+"\\"
            print self.backupfile
            try:
                os.makedirs(self.backupfile)
            except:
                pass

            self.backupfile = self.backupfile + file_name + '_' + datelogtest + "Log_all.txt"
            shutil.move(
                "C:\\LitePoint\\IQfact_plus\\Realtek 8822 3.3.0.Eng25_Lock\\Bin\\Log\\Log_all.txt",self.backupfile)
        except:
            print "can not remove file"

    def saveLogTel(self, file_name):
        testdate = datetime.datetime.now()
        datelogtest = str(testdate.year) + '_' + str(testdate.month) + '_' + str(testdate.day) + '_' + str(
            testdate.hour) + '_' + str(testdate.minute) + '_' + str(testdate.second)
        try:
            self.backupfile = "D:\\Telnet_log\\"+ self.project_name + "\\" + str(
                datetime.datetime.now().__format__('%d-%m-%Y')) + "\\"
            print self.backupfile
            try:
                os.makedirs(self.backupfile)
            except:
                pass

            self.backupfile = self.backupfile + file_name + '_' + datelogtest + "Telnet_log.txt"
            shutil.move(
                "C:\\TMMSeq\\Stat\\Telnet_'+'*.log", self.backupfile)
        except:
            print "can not remove file"
    def saveLogTelnet(self):
        self.aa=testclass1.Backup_Telnet()
        self.aa.start()

#-------------------------Upload log file to FTP--------------------------------------------------------
    def Create_FTP_Folder(self, working_dir):
        # self.ftppth = 'Logs/' + self.Model + '/' + self.Station + '/' + self.PC_Name + '/' + self.date
        try:
            self.ftp_connection.cwd(working_dir)  # change work folder,if fail it create folder directly
        except:
            self.ftp_connection.mkd(working_dir)
            self.ftp_connection.cwd(working_dir)

    def Create_FTP_Dir(self, working_dir):
        try:
            #print('iiiiii: start')
            print(working_dir)
            folder_list = working_dir.split('/')
            flen = len(folder_list) - 1
            if (flen <= 0):
                folder_list = working_dir.split('\\')
                flen = len(folder_list) - 1
            print('iiiiii: ' + str(flen))
            idir = folder_list[0]
            for i in range(0, flen):
                idir = folder_list[i]
                #print('iiiiii: ' + idir)
                self.Create_FTP_Folder(idir)
        except Exception as e:
            print('create_ftp_dir:', e)

    def Upload_File(self, server, user, pwd, filepath, savepath):
        bResult = False
        try:
            self.ftp_connection = ftplib.FTP(server, user, pwd)
            self.ftp_connection.set_pasv(False)
            fh = open(filepath, 'rb')
            filename = os.path.basename(filepath)
            self.Create_FTP_Dir(savepath)
            if self.ftp_connection.storbinary('STOR ' + filename, fh):  # Upload files
                bResult = True
            fh.close()
            return bResult
        except Exception as e:
            print('print ftp:', e)
            return False
#------------------------Upload logfile to SFTP---------------------------------------------------------------
    def SFTP_Upload(self,server,user,pwd,filepath,savepath):
        #bResult = False
        print "Upload file=" + filepath
        print "Upload file=" + savepath
        remotefile = os.path.basename(filepath)
        r_file = os.path.join(savepath, remotefile)
        try:
            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = None
            conn = pysftp.Connection(host=server, port=22, username=user, password=pwd, cnopts=cnopts)
            print("connection established successfully")
            print(conn.pwd)
            conn.chdir('/Logs')
            # print(conn.pwd)
            print(conn.pwd)

            if conn.exists(savepath) is False:
                print("dir=" + savepath)
                conn.makedirs(savepath)
            conn.put(filepath, r_file)
            conn.close()
            return True

        except Exception as e:
            print(str(e))
            print('failed to establish connection to targeted server')
            return False

#-----------------------Save log combine telnet and traces log-------------------------------------------------------

    def Save_log(self):
        print('Luu log day')
        self.date = datetime.datetime.today().strftime('%Y-%m-%d')
        dt = datetime.datetime.today()
        self.time_end = dt.strftime('%Y-%m-%d-%H-%M-%S')
        self.Log_Folder = "d:\\Log_backup\\"
        self.FPT_folder = "Logs\\"
        # self.Log_Folder="D:\\Log_backup\\"+ str(datetime.datetime.now().__format__('%d-%m-%Y'))
        self.Model = self.project_name
        self.Station = self.project_station
        self.PC_Name = self.hostname
        self.SN = self.test_sn
        self.server = "200.168.104.98"
        self.user = "Logs"
        self.pwd = "Logs"
        #self.Log_File="SFC log"+self.textEdit.toPlainText()+"\n"
        self.Log_File = 'Start Test ' + datetime.datetime.today().strftime('%Y-%m-%d-%H-%M-%S') + '\n'

        '''self.Telnet_back_up = "D:\\Logs_Telnet\\" + self.Model + "\\" + self.Station + "\\" + self.PC_Name + "\\" + self.date + "\\" + log
        # print "PC_backup: " + self.PC_back_up
        if not os.path.exists(os.path.dirname(self.Telnet_back_up)):
            os.makedirs(os.path.dirname(self.Telnet_back_up))
        '''
        p = glob.glob("C:\\TMMSeq\\Stat\\Telnet_*.log")
        #print(p)
        for i in p:
            with open(i, 'r') as f:
                self.Log_File = self.Log_File + os.path.basename(i) + '\n'
                self.buf_log = f.read()
                #print("***" + self.Log_File)
                self.Log_File = self.Log_File + self.buf_log
                f.close()
            os.remove(i)
            #shutil.move(self.Log_File,self.Telnet_back_up)
        '''l = glob.glob("C:\\TMMSeq\\Stat\\IQLITE_*.log")
        print(l)
        for n in l:
            with open(n, 'r') as f:
                self.Log_File = self.Log_File + os.path.basename(n) + '\n'
                self.buf_log = f.read()
                # print("***" + self.Log_File)
                self.Log_File = self.Log_File + self.buf_log
            os.remove(n)
        '''

        k = glob.glob("C:\\Traces\\*.txt")
        #print (k)
        #----backup log
        #if not os.path.exists("D:\\Traces"):
            #os.makedirs("D:\\Traces")
        for j in k:
            #print (j)
            #shutil.copyfile(j, "D:\\Traces\\" + os.path.basename(j))# ----backup log
            with open(j, 'r') as f1:
                self.Log_File = self.Log_File + '\n' + os.path.basename(j) + '\n'
                #print (self.Log_File)
                buf_log1 = f1.read()
                self.Log_File = self.Log_File + buf_log1
                #print("@@@@" + buf_log1)
                f1.close()
            os.remove(j)
        date = datetime.datetime.today().strftime('%Y-%m-%d')
        dt = datetime.datetime.today()
        time_end = dt.strftime('%Y-%m-%d-%H-%M-%S')
        file = os.path.join(self.Log_Folder, self.Model, self.Station, self.PC_Name, self.date, self.SN + "_" + time_end + '.txt')

        #print(file)
        #print (self.Log_File)
        if not os.path.exists(os.path.dirname(file)):
            os.makedirs(os.path.dirname(file))
        with open(file, 'w') as f:
            f.write(self.Log_File)
        #print "source" + file
        path = "Logs\\" + self.Model + "\\" + self.Station + "\\" + self.PC_Name + '\\' + date+'\\'
        # self.fpt_back=path+file
        # print "fpt"+self.fpt_back
        os.chdir(os.path.join(self.Log_Folder, self.Model, self.Station, self.PC_Name, date))
        for log in glob.glob("*.txt"):
            self.log_file = self.Log_Folder + "\\" + self.Model + "\\" + self.Station + "\\" + self.PC_Name + "\\" + date + '\\' + log
            #print "log_file: " + self.log_file
            self.fpt_back = path + log
            #print log
            #print "fpt: " + self.fpt_back
            self.PC_back_up = "D:\\Logs\\" + self.Model + "\\" + self.Station + "\\" + self.PC_Name + "\\" + date + "\\" + log
            #print "PC_backup: " + self.PC_back_up
            if not os.path.exists(os.path.dirname(self.PC_back_up)):
                os.makedirs(os.path.dirname(self.PC_back_up))
            try:
                self.SFTP_Upload("200.168.104.98", "sftp", "tenpi", self.log_file, self.fpt_back)
            except Exception as e:
                print "Error"+ e
            shutil.move(self.log_file, self.PC_back_up)
# ---------------------------------Save Log testtime json-----------------------------------------
        a = "D:\\Test_Program\\"+self.Model+"\\"+self.Station+"\\luujson_20230831.exe" + " " + self.SN
        os.chdir("D:\\Test_Program\\"+self.Model+self.Station+"\\")
        os.system(a)
        os.chdir("C:\\Trinity\\TestJson_out\\Moved")
        for logf in glob.glob(self.SN + ".json"):
            if logf is not None:
                self.jsonlog = "C:\\Trinity\\TestJson_out\\Moved\\" + logf
            self.fpt_back = path + logf
            self.PC_back_up = "D:\\Logs\\" + self.Model + "\\" + self.Station + "\\" + self.PC_Name + "\\" + date + "\\" + logf
            try:
                self.Upload_File("10.228.110.180", "Logs_json", "Logs_json", self.jsonlog, self.fpt_back)
            except Exception as e:
                print  e
            shutil.move(self.jsonlog, self.PC_back_up)

#-----------------------------back up telnet log----------------------------------------------
        #os.chdir("C:\\TMMSeq\\Stat")
        #for loge in glob.glob("Telnet_*.log"):
            #if loge is not None:
                #self.telnetlogs = "C:\\TMMSeq\\Stat\\" + loge
            #self.fpt_back = pat
            # h + loge

           # shutil.move(self.telnetlogs, self.PC_back_up)
# --------------------------Save json log-----------------------------------------------------
        os.chdir("C:\\Trinity\\TestJson_out\\Moved")
        for logj in glob.glob("*.json"):
            if logj is not None:
                self.jsonlog = "C:\\Trinity\\TestJson_out\\Moved\\" + logj
            self.fpt_back = path + logj
            self.PC_back_up = "D:\\Logs\\" + self.Model + "\\" + self.Station + "\\" + self.PC_Name + "\\" + date + "\\" + logj
            try:
                self.Upload_File("200.168.104.98", "sftp", "tenpi", self.jsonlog, self.fpt_back)
            except Exception as e:
                print  e
            shutil.move(self.jsonlog, self.PC_back_up)

#---------------------------------------Main Function to init GUI-------------------------------------------------------
if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    window = SfcWindow()
    window.setFixedSize(window.width(),window.height())
    sys.exit(app.exec_())