import subprocess
try:
    p = subprocess.Popen("arp-d", shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE,
                              stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    print stdout
except:
    print 'adb read error'