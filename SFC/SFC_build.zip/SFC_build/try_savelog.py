import os
import datetime
import glob
import re
def Savelog():
    '''if os.path.exists("C:\\TMMSeq\\data.json"):
        os.remove("C:\\TMMSeq\\data.json")
    '''
    Log_Folder="d:\\Log_backup\\"
    Model="ABC"
    Station="CT"
    PC_Name="EFG"
    SN="01234556"
    Log_File = 'Start Test ' + datetime.datetime.today().strftime('%Y-%m-%d-%H-%M-%S') + '\n'
    p = glob.glob("C:\\TMMSeq\\Stat\\*.log")
    for i in p:
        with open(i, 'r') as f:
            Log_File = Log_File + os.path.basename(i) + '\n'
            buf_log = f.read()
            print("***"+Log_File)
            Log_File=Log_File+buf_log
    k=glob.glob("C:\\Traces\\*.txt")
    for j in k:
        with open(j,'r') as f1:
            Log_File=Log_File +os.path.basename(j)+'\n'
            buf_log1=f1.read()
            Log_File=Log_File+buf_log1
            print("@@@@"+buf_log1)
    date = datetime.datetime.today().strftime('%Y-%m-%d')
    dt = datetime.datetime.today()
    time_end = dt.strftime('%Y-%m-%d-%H-%M-%S')
    file = os.path.join(Log_Folder, Model, Station, PC_Name, date,SN + "_" + time_end + '.txt')
    if not os.path.exists(os.path.dirname(file)):
        os.makedirs(os.path.dirname(file))
    with open(file, 'w') as f:
        f.write(Log_File)
    #Log_File="d:\\Log_backup\\"+SN+".txt"




Savelog()
