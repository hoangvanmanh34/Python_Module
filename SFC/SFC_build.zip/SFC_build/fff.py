import hashlib
import os
import glob

def TMM_PC_MD5():
    # self.Test_sequence_name = self.XML_GET(self.xml1, "Test_sequence_name", "Name")
    # if not os.path.exists(os.path.isfile("C:\\TMMSeq\\Sequences\\"+self.Model+"\\*.Seq")):
    Model="UZW4020BYT3"
    #Model="RF"
    md5_hash = hashlib.md5()
    if not os.path.exists(os.path.dirname("C:\\TMMSeq\\Sequences\\" + Model)):
        os.makedirs(os.path.dirname("C:\\TMMSeq\\Sequences\\" + Model))
    os.chdir("C:\\TMMSeq\\Sequences\\" + Model + "\\")
    m = glob.glob("C:\\TMMSeq\\Sequences\\" + Model + "\\*.Seq")
    print m
    for n in m:
        with open(n, 'r') as conent:
            file_name = os.path.basename(n)
            print file_name
            md5_hash.update(file_name)
            degest = md5_hash.hexdigest()
            degest = degest.upper()
            print "TMM_PC MD5:  " + degest
    #self.MD5_config = self.XML_GET(self.xml1, "Test_sequence_MD5", "MD5")
    #self.Test_sequence_name = self.XML_GET(self.xml1, "Test_sequence_name", "Name")
    MD5_config="bfyuedtgfebfiuye"
    if MD5_config == degest:
        return True
    else:
        print "MD5_config:  " + MD5_config
        return False

a=TMM_PC_MD5()
print a
if TMM_PC_MD5()== False:
    print "1"
else:
    print "2"
