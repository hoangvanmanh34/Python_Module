import requests,socket,ast
import datetime,time
import xmlaccess,unlock_file,testclass
from datetime import time
class API:

    setting_file = "./setting\\setting.xml"
    xml1 = xmlaccess.xml_access(setting_file)

    def __init__(self):
        #self.MODEL_NAME='UZW4020BYT'
        self.FIX_NAME=socket.gethostname()
        #self.FIX_NAME1='UZW4020BYT'
        #self.STATION='CT'
        self.MODEL_NAME = self.XML_GET(self.xml1, "Project", "project_name")
        self.STATION = self.XML_GET(self.xml1, "Project", "project_station")



    def XML_GET(self, XMLACESS, MainField, ClienField):
        self.XMLDATA = XMLACESS.xml_com_name(MainField, ClienField)
        for ID in self.XMLDATA:
            self.xmldata = ID.get('name')
            return self.xmldata

    def Check_lock_FPY(self):
        a=datetime.datetime.now()
        check_time=time(a.hour,a.minute,a.second)
        if time(8,27,00)<=check_time<=time(8,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass

        elif time(9,27,00)<=check_time<=time(9,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(10,27,00)<=check_time<=time(10,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(11,27,00)<=check_time<=time(11,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(12,27,00)<=check_time<=time(12,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(13,27,00)<=check_time<=time(13,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(14,27,00)<=check_time<=time(14,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(15,27,00)<=check_time<=time(15,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(16,27,00)<=check_time<=time(16,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(17,27,00)<=check_time<=time(17,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(18,27,00)<=check_time<=time(18,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(19,27,00)<=check_time<=time(19,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(20,27,00)<= check_time<=time(20,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']

                return result
            except:
                pass
        elif time(21,27,00)<=check_time<=time(21,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(22,27,00)<=check_time<=time(22,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(23,27,00)<=check_time<=time(23,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(0,27,00)<check_time<=time(0,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(1,27,00)<=check_time<=time(1,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(2,27,00)<=check_time<=time(2,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(3,27,00)<=check_time<=time(3,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(4,27,00)<=check_time<=time(4,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(5,27,00)<=check_time<=time(5,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(6,27,00)<=check_time<=time(6,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                result = result['data']['isStop']
                return result
            except:
                pass
        elif time(7,27,00)<=check_time<=time(7,29,00):
            try:
                r = requests.get(
                    'https://10.228.110.91/e-totally-api/v1/report/TestRate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=' + self.MODEL_NAME + '&groupname=' + self.STATION + '&stationname=' + self.FIX_NAME)
                data = (r.content)
                result = data.replace('null', 'None')
                result = result.replace('false', '0')
                result = result.replace('true', '1')
                result = ast.literal_eval(result)
                #result1 = result['data']['isStop']
                #result2= result['data']['fpy']
                #result3=result['data']['errorCodes']

                #return result1,result2,result3
                return result
            except:
                pass
    def Unlock_FPY(self):
        try:
            f = open('E:/dist/unlock.lk', 'r')
            contents = f.read()
            if (str(contents).find('1') != -1):
                self.Errocode = contents[8:16]

            data_up = {
                "ModelName": self.MODEL_NAME,
                "GroupName": self.STATION,
                "StationName": self.FIX_NAME,
                "ErrorCodeToUpdate": self.Errocode
            }
            from urllib3.exceptions import InsecureRequestWarning
            requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
            r = requests.put(r"https://10.228.110.91/e-totally-api/v1/Report/TestRate/UpdateTopErrorCode", data_up,
                             verify=False)
            e = requests.get(r"https://10.228.110.91/e-totally-api/v1/Report/TestRate/GetTopErrorCode",
                             verify=False)
            print(e)
            #r.close()
        except Exception as e:
            print e
    def Top_three_Errocode(self):
        #print self.MODEL_NAME
        print self.STATION
        r=requests.get('https://10.228.110.91/e-totally-api/v1/report/testrate/GetTopErrorCodeLastHourByStationName?modelName='+self.MODEL_NAME+'&stationName='+self.FIX_NAME,verify=False)
        data =r.content.decode()
        data=data.replace('null','None')
        result=ast.literal_eval(data)['data']
        return result
        #print result
    def Send_Lock_API(self):
        locksg= {
            
        }

#r = requests.get('http://10.228.110.91/e-totally-api/v1/report/testrate/GetTopErrorCodeLastHourByStationName?modelName=HSV2034TAT3&stationName=HSVTAT3FCT25')
#p=requests.get('')
#print(r)
#print(r.content)
