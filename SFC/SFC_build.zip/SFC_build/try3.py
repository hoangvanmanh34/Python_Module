import hashlib,datetime

#def md5Checksum(filePath):
with open("C:\\Phoenix\\Sequences\\UZW4020BYT4\\UZW4020BYT3-BYT4_FXC_VN_BTC_1.38_V004E.json", 'rb') as fh:
    m = hashlib.md5()
    data = fh.read(8192)
    m.update(data)
    md5sq = m.hexdigest()
    print md5sq
    print type(md5sq)

#fil = "C:\\Users\\Administrator\\Desktop\\2\\UZW4020BYT3-BYT4_FXC_VN_BTC_1.38_V004E.json"
#fil1 = "E:\\UUT.txt"
#f = md5Checksum(fil)
#print f
#print str(datetime.datetime.now())
#39d8955e5bcb4e22ccc22b6c5f7a578f
#ae34133ec1640dd80b377c40899a5230
#ae34133ec1640dd80b377c40899a5230