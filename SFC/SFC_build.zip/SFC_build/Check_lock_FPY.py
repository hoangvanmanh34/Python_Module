import requests
from datetime import datetime
import time
import threading
import os
from winreg import *
import xmlaccess
import socket
import ast
import urllib3
import configparser
import json
class API():
    setting_file = "./setting\\setting.xml"
    xml1 = xmlaccess.xml_access(setting_file)

    def XML_GET(self, XMLACESS, MainField, ClienField):
        self.XMLDATA = XMLACESS.xml_com_name(MainField, ClienField)
        for ID in self.XMLDATA:
            self.xmldata = ID.get('name')
            return self.xmldata
    def __init__(self):
        self.Hostmane=socket.gethostname()
        print "test machine:    "+self.Hostmane
        self.Modelname=self.XML_GET(self.xml1, "Project", "project_name")
        self.Stationname=self.XML_GET(self.xml1, "Project", "project_station")

        #self.Hostmane="SMLL04CTFV07"
        #self.Modelname="UZW4020BYT4"
        #self.Stationname="CT"
    def Check_lock_FPY_status(self):
        s = requests.session()
        urllib3.disable_warnings()
        a=r"https://10.228.110.91/e-totally-api/v1/report/testrate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname="+self.Modelname+"&stationname="+self.Hostmane+"&groupname="+self.Stationname
        try:
            r=s.get(a, verify=False, timeout=60)
            data=r.text
            self.Save_log("Lock_status:`"+data)
            '''data = (r.content)
            result = data.replace('null', 'None')
            result = result.replace('false', '0')
            result = result.replace('true', '1')
            result = ast.literal_eval(result)
            result1 = result['data']['isStop']
            result2=result["data"]["stopType"]
            return  result1,result2
            '''

            ret = json.loads(r.text)
            print data
            print ret
            if ret['data']['isStop'] == True:
                mote = ret['data']['stopType']
                print(mote)
                errocode = ret["data"]["errorCodes"]
                errocode = str(errocode)
                print errocode
                print type(errocode)
                if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
                    config = configparser.ConfigParser()
                    config.optionxform = str
                    config.read("E:\\dist\\DATA_FPY.ini")
                    try:
                        config.set("FPY", "LockFPY", str(mote))
                        config.set("FPY", "ErrorCode", str(errocode))
                        with open("E:\\dist\\DATA_FPY.ini", "w") as configfile:
                            config.write(configfile)
                    except:
                        pass
        except:
            pass
    def Lock_FPY(self):
        now = datetime.now()
        current_H = now.strftime("%H")
        current_M = now.strftime("%M")
        if int(current_H) != 9 or int(current_H) != 10 or int(current_H) != 11 or int(current_H) != 14 or int(current_H) != 15 or int(current_H) != 16:
            if int(current_M) == 30:
                self.Check_lock_FPY_status()
                '''call=self.Check_lock_FPY_status()
                call=str(call)
                status=call[1]
                typelock=call[4]
                if status.find("1")!=-1:
                    if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
                        config = configparser.ConfigParser()
                        config.optionxform = str
                        config.read("E:\\dist\\DATA_FPY.ini")
                        try:
                            config.set("FPY", "LockFPY", str(typelock))
                            with open("E:\\dist\\DATA_FPY.ini", "w") as configfile:
                                config.write(configfile)
                        except:
                            pass
                    '''

    def Unlock_FPY(self):
        s = requests.session()
        if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
            config = configparser.ConfigParser()
            config.read("E:/dist/DATA_FPY.ini")
            self.errocode = config.get("FPY", "ErrorCode")
            self.description=config.get("FPY","Description")
            self.rootcause=config.get("FPY","Rootcause")
            self.action=config.get("FPY","Action")
            self.idcard=config.get("FPY","IDcard")
        try:
            pa = {
                "ModelName": self.Modelname,
                "GroupName": self.Stationname,
                "StationName": self.Hostmane,
                "ErrorCodeToUpdate": self.errocode,
                "Actdescription": self.description,
                "Rootcause": self.rootcause,
                "ActDescription": self.action,
                "Unlockby": self.idcard
            }
            b=r"https://10.228.110.91/e-totally-api/v1/Report/TestRate/UpdateTopErrorCode"
            r=s.put(b,pa,verify=False, timeout=60)
            data = r.text
            if r.status_code == 200:
                #upok = False
                print "unlock fail"
            print(data)
            self.Save_log("Unlock ok"+data)

        except Exception as e:
            print(e)
    def Save_log(self,logfile):
        now = datetime.now().strftime("%Y")
        secon = datetime.today().strftime('%Y-%m-%d-%H:%M:%S: ')
        Logfile = "E:\\dist\\"+"Log_lock_"+ str(now)+".txt"
        with open(Logfile, 'a') as log:
            log.writelines(secon +logfile +"\r")
            log.close()

        #F = open("Log_FPY_" + str(now) + ".txt", "a")
        #F.writelines(secon + logfile + "\r")
        #F.close()

if __name__ == '__main__':
    pass