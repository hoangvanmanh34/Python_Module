import telnetclass
import datetime,time
from datetime import time
from threading import Thread
from ast import literal_eval

def Reboot():
    try:
        with open('config.json','r') as f:
            data=f.read().strip()
            f.close()
            cfg_value_list=literal_eval(data)
            IP=cfg_value_list["IP"]

    except Exception as e:
        return  False
    '''file=open('D:\\config.txt','r')
    cfile=file.read()
    cfile=literal_eval(cfile)
    IP=int(cfile[0])
    '''
    a = datetime.datetime.now()
    check_time = time(a.hour, a.minute, a.second)
    if check_time==(6,00,00):
        telnet_section=telnetclass.TELNET(IP,'23')
        time.sleep(2)
        telnet_section=telnetclass.TELNET("reboot\r\n")
        data=telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time==(7,00,00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time==(8,00,00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')

    if check_time==(9,00,00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')

    if check_time==(10,00,00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')

    if check_time == (11, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (12, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (13, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (14, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (15, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (16, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (17, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (18, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (19, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (20, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (21, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (22, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (23, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (0, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (1, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (2, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (3, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (4, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
    if check_time == (5, 00, 00):
        telnet_section = telnetclass.TELNET(IP, '23')
        time.sleep(2)
        telnet_section = telnetclass.TELNET("reboot\r\n")
        data = telnet_section.TELNET_RECIVE_EXPECT('#')
Thread(target=Reboot).start()
