import serial,PyQt4
from PyQt4 import QtCore
import sys

class SERIAL_OB(QtCore.QThread):
    def __init__(self, SER_PORT, name, parent=None):
        super(SERIAL_OB, self).__init__(parent)
        self.SER_PORT = SER_PORT
        self.name = name
        self.Section = serial.Serial(
            port=self.SER_PORT,
            baudrate=9600,
            parity='N',
            bytesize=8,
            stopbits=1
            )
    def SERIAL_OPEN(self):
        self.Section.close()
        self.Section.open()
        #print self.SER_PORT
    def run(self):

        while 1:
            if (self.name=='TMM'):
                TMM_BUFF = self.readline1()
                self.emit(QtCore.SIGNAL('TMM_ACTION'), TMM_BUFF )
            if (self.name=='SFC'):
                SFC_BUFF = self.Section.readline()
                self.emit(QtCore.SIGNAL('SFC_ACTION'), SFC_BUFF )



    def SERIAL_WRITE(self,s_string):
        s_string = s_string+"\r\n"
        self.Section.write(s_string)
    def SERIAL_CLOSE(self):
        self.Section.close()
        self.Section.close()
    def stop(self):
        self.terminate()
        self.quit()
        self.exit()
        self.stopped =True
        self.terminated = True
    def readline1(self, size=None, eol="\r"):
        """read a line which is terminated with end-of-line (eol) character
        ('\n' by default) or until timeout."""
        leneol = len(eol)
        line = bytearray()
        while True:
            c = self.Section.read(1)
            if c:
                line = line+ c
                if line[-leneol:] == eol:
                    break
                if size is not None and len(line) >= size:
                    break
            else:
                break
        return bytes(line)
