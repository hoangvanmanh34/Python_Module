import FTP_Trans,os,datetime,pathlib,time
from os import path
def SaveLog(self):
        try:

            AllLog = self.log.get(1.0, END)
            datetosave = str(datetime.now().__format__('%d-%B-%Y'))
            timetosave = str(datetime.now().__format__('%d-%B-%Y_%H-%M-%S'))
            full_savedir = 'D:/Logs/' + self.Model + '/' + self.Station + '/' + self.PC_Name + '/' + datetosave
            savedir = 'Logs/'+self.Model + '/' + self.Station + '/' + self.PC_Name + '/' + datetosave
            if not os.path.isdir(full_savedir): os.makedirs(full_savedir)
            self.Get_Log_Name()
            if self.Test_Type == 'SELF':
                title_scan = 'Test Item  /  SN:' + self.Log_Result_Name
                self.lbListItem.configure(text=title_scan)
            if self.Test_Type == 'SELF_NO_FIXTURE':
                title_scan = 'Test Item  /  SN:' + self.Log_Result_Name
                self.lbListItem.configure(text=title_scan)
            log_file = open(full_savedir + '/' + self.Log_Result_Name + '_' + timetosave + '.txt', 'w')
            log_file.write(AllLog)
            log_file.close()
            if not path.isfile(full_savedir + '/Summary_Log.txt'):
                sum_file = open(full_savedir + '/Summary_Log.txt', 'w')
                Sum_File_Head = 'Result\tError_Code\tSN\tModel\tStation\tPC_Name\tMain_Version\tFinish_Date_Time\tTest_Time'
                sum_file.write(Sum_File_Head)
                sum_file.close()
                time.sleep(0.5)
            if self.Final_Result : total_result = 'PASS'
            else : total_result = 'FAIL'
            sum_file = open(full_savedir + '/Summary_Log.txt')
            sum_file.mode = 'r'
            sum_content = sum_file.read()
            sum_file.close()
            sum_file = open(full_savedir + '/Summary_Log.txt', 'w')
            sum_file.write(sum_content+'\n'+total_result+'\t'+self.Error_code+'\t'+self.Log_Result_Name+'\t'+self.Model+'\t'+self.Station+'\t'+str(self.PC_Name)+'\t'+self.Test_Control_Ver+
                           '\t'+timetosave+'\t'+str(round(self.End_Time - self.Start_Time)))#(self.End_Time - self.Start_Time).seconds
            sum_file.close()
            time.sleep(0.5)
            #if not path.isdir('D:/Test_program/Module/Main/Data_Logs'):os.makedirs('D:/Test_program/Module/Main/Data_Logs')
            #shutil.copy('D:/Test_program/Module/Main/data.json','D:/Test_program/Module/Main/'+self.Log_Result_Name+ '_' + timetosave + '.txt',savedir)
            for i in range(0,2):
                if path.isfile(full_savedir + '/' + self.Log_Result_Name+ '_' + timetosave + '.txt') and path.isfile(full_savedir + '/Summary_Log.txt'):
                    if not FPT_Trans.Upload_File(self.Log_IP, self.Log_User, self.Log_Password,
                                                 full_savedir + '/' + self.Log_Result_Name + '_' + timetosave + '.txt',savedir):
                        time.sleep(0.5)
                        if not FPT_Trans.Upload_File(self.Log_IP, self.Log_User, self.Log_Password,
                                                     full_savedir + '/' + self.Log_Result_Name + '_' + timetosave + '.txt',
                                                     savedir):
                            print('Save log to FTP fail')
                    if not FPT_Trans.Upload_File(self.Log_IP, self.Log_User, self.Log_Password,
                                                 full_savedir + '/Summary_Log.txt',savedir):
                        time.sleep(0.5)
                        if not FPT_Trans.Upload_File(self.Log_IP, self.Log_User, self.Log_Password,
                                                     full_savedir + '/Summary_Log.txt',savedir):
                            print('Save summary log to FTP fail')
                    break
                time.sleep(0.5)
        except Exception as e:
            print('save log fail')
            print(e)