import configparser


def Create_New(dir,section,item,value):
    config = configparser.ConfigParser()
    config[section] = {item : value}
    with open(dir, 'w') as configfile:
        config.write(configfile)

def Add_Section(dir,section,item,value):
    config = configparser.RawConfigParser()
    config.optionxform = str
    config.add_section(section)
    config[section] = {item: value}
    with open(dir, 'a') as configfile:
        config.write(configfile)

def Add_Item(dir,section,item,value):
    config = configparser.RawConfigParser()
    config.read(dir)
    config.set(section,item,value)
    with open(dir, 'w') as configfile:
        config.write(configfile)

def Remove_Item(dir,section,item):
    config = configparser.RawConfigParser()
    config.read(dir)
    config.remove_option(section,item)
    #with open(dir, 'w') as configfile:
        #config.write(configfile)

def Update_Item(dir,section,item,value):
    config = configparser.RawConfigParser()
    config.read(dir)
    config.set(section, item, value)

def Read_Value(dir,section,item,value_type):
    config = configparser.RawConfigParser()
    config.read(dir)
    if value_type == 'int':
        value = config.getint(section, item)
    else :
        value = config.get(section, item)
    return value


#Create_New('D:/Manh/Source/python/Work_program/untitled/config.ini','CAMERA','Index','1')
#Add_Section('D:/Manh/Source/python/Work_program/untitled/config.ini','DUT','IP','192.168.1.1')
#Add_Item('D:/Manh/Source/python/Work_program/untitled/config.ini','DUT','Login_type','Putty')
#print(Read_Value('D:/Manh/Source/python/Work_program/untitled/config.ini','CAMERA','Index','str'))
