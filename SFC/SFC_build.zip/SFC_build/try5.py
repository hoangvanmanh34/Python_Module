import requests
import ast
import urllib3
import json
urllib3.disable_warnings()
s = requests.session()
Modelname="UZW4020BYT4"
Hostname=""
Stationname="CT"
a= r"https://10.228.110.91/e-totally-api/v1/report/testrate/CheckFpyRateByModelNameAndGroupNameAndStationName?modelname=" + Modelname + "&stationname=" + Hostname + "&groupname=" + Stationname
print a
try:
    r = s.get(a,verify=False, timeout=60)
    data=r.text
    ret = json.loads(r.text)
    print data
    print ret
    if ret['data']['isStop'] == False:
        mote = ret['data']['stopType']
        print(mote)
        errocode=ret["data"]["errorCodes"]
        errocode=str(errocode)
        print errocode
        print type(errocode)
    if Hostname!="":
        print "ok"
    else:
        print "nok"

    '''data = (r.content)
    result = data.replace('null', 'None')
    result = result.replace('false', '0')
    result = result.replace('true', '1')
    result = ast.literal_eval(result)
    result1 = result['data']['isStop']
    result2 = result["data"] ["stopType"]
    result1 = str(result1)
    print "result1: "+ str(result1)
    print "result2: "+str(result2)
    if result1.find("1")!=-1:
        print "lock"
    else:
        print "khong lock"
    '''
except Exception as e:
    print e


import Check_lock_FPY
import os
import configparser
import datetime
from datetime import datetime
'''a=Check_lock_FPY.API()
b=a.Check_lock_FPY_status()
b=str(b)
print b
b1=b[1]
b2=b[4]
print b1
print type(b1)
print b2
if b1.find("0") != -1:
    if os.path.isfile("E:\\dist\\DATA_FPY.ini"):
        config = configparser.ConfigParser()
        config.optionxform = str
        config.read("E:\\dist\\DATA_FPY.ini")
        try:
            config.set("FPY", "LockFPY", str(b2))
            with open("E:\\dist\\DATA_FPY.ini", "w") as configfile:
                config.write(configfile)
        except:
            pass
else:
    print "khong can update"
print type(b2)
print type(b)
'''
'''now = datetime.now().strftime("%Y")
secon = datetime.today().strftime('%Y-%m-%d-%H:%M:%S: ')
Logfile = "E:\\dist\\" + "Log_lock_FPY_" + str(now) + ".txt"
with open(Logfile, 'a') as logfile:
    logfile.writelines("abc")
    logfile.close()
'''