import ftplib
import time
import os
import json
import os
import io
import sys
import zipfile

ftp_ip = '200.168.104.98'
ftp_user = 'Manh'
ftp_password = 'Manh!!'

def Download_File_CFG(server,username,password,working_dir,filename):
    bResult=False
    try:
        ftp_connection = ftplib.FTP(server,timeout=15)
        ftp_connection.login(username, password)
        ftp_connection.set_pasv(False)
        ftp_connection.cwd(working_dir)
        # Get All Files
        # files = ftp.nlst()
        # Print out the files
        '''for file in files:
            print("Downloading..." + file)
            ftp.retrbinary("RETR " + file, open("download/to/your/directory/" + file, 'wb').write)'''
        time.sleep(0.5)

        localfile = open('C:/TMMSeq/U46X424.03/RF/' + filename, 'wb')
        if ftp_connection.retrbinary('RETR ' + filename, localfile.write, 1001024):
            bResult=True
        ftp_connection.quit()
        localfile.close()
        ftp_connection.close()
        return bResult
    except:
        print('download '+working_dir+'/'+filename+' failed')
        return False

def Download_File(server,username,password,working_dir,foldername,filename):
    bResult=False
    try:
        ftp_connection = ftplib.FTP(server,timeout=15)
        ftp_connection.login(username, password)
        ftp_connection.set_pasv(False)
        ftp_connection.cwd(working_dir)
        # Get All Files
        # files = ftp.nlst()
        # Print out the files
        '''for file in files:
            print("Downloading..." + file)
            ftp.retrbinary("RETR " + file, open("download/to/your/directory/" + file, 'wb').write)'''
        time.sleep(0.5)

        localfile = open(foldername+'/' + filename, 'wb')
        if ftp_connection.retrbinary('RETR ' + filename, localfile.write, 1001024):
            bResult=True
        ftp_connection.quit()
        localfile.close()
        ftp_connection.close()
        return bResult
    except:
        print('download '+working_dir+'/'+filename+' failed')
        return False

def Upload_File(server,username,password,filepath,savepath):
    bResult=False
    try:
        ftp_connection = ftplib.FTP(server, username, password)
        ftp_connection.set_pasv(False)
        #ftp_connection.cwd(working_dir)
        fh = open(filepath, 'rb')
        filename=os.path.basename(filepath)
        #---------Check dir---------------------
        Create_FTP_Dir(server,username,password,savepath)
        #---------------------------------------
        if ftp_connection.storbinary('STOR '+savepath+'/'+filename, fh):
            bResult = True
        fh.close()
        return bResult
    except:# Exception as e:
        #print(e)
        return False

def Create_FTP_Folder(server,username,password,working_dir,ifolder):
    ftp_connection = ftplib.FTP(server,username, password)
    #ftp_connection.login(username, password)
    ftp_connection.set_pasv(False)
    ftp_connection.cwd(working_dir)
    alist = []
    folderList=[]
    ftp_connection.retrlines('mlsd',alist.append)
    #print(alist)
    check_result = False
    for li in alist:
        if 'Type=dir' in li:
            folderList.append(li)
    #print(folderList)
    for dli in folderList:
        if ifolder in dli:
            check_result = True
    if check_result==False:
        ftp_connection.mkd(ifolder)
    else : print('existed')

def Create_FTP_Dir(server,username,password,working_dir):
    folder_list=working_dir.split('/')
    flen = len(folder_list)-1
    #print(folder_list)
    idir=folder_list[0]
    for i in range(0,flen):
        if i>0:
            idir += '/'+folder_list[i]
        #print(idir)
        Create_FTP_Folder(server,username,password, idir, folder_list[i+1])

def Folder_List(server,username,password,working_dir):
    ftp_connection = ftplib.FTP(server, timeout=15)
    ftp_connection.login(username, password)
    ftp_connection.set_pasv(False)
    ftp_connection.cwd(working_dir)
    # Get All Files
    folders = ftp_connection.nlst()
    # Print out the files
    Flist=[]
    #print(len(folders))
    for folder in folders:
        if str(folder) != '...' and str(folder) != '..' and str(folder) != '.' and str(folder).find('.zip') == -1 and str(folder).find('.7z') == -1 and str(folder).find('.json') == -1 and str(folder).find('.bat') == -1 and str(folder).find('.ini') == -1 and str(folder).find('.doc') == -1 and str(folder).find('.txt') == -1 and str(folder).find('.py') == -1 and str(folder).find('.exe') == -1 and str(folder).find('.xlsx') == -1 and str(folder).find('.rar') == -1 and str(folder).find('.dll') == -1 and str(folder).find('.lib') == -1 and str(folder).find('.h') == -1 and str(folder).find('.cpp') == -1:
            #print(folder)
            Flist.append(folder)
    return  Flist

def File_List(server,username,password,working_dir):
    ftp_connection = ftplib.FTP(server, timeout=15)
    ftp_connection.login(username, password)
    ftp_connection.set_pasv(False)
    ftp_connection.cwd(working_dir)
    # Get All Files
    files = ftp_connection.nlst()
    # Print out the files
    Flist=[]
    for file in files:
        if str(file).find('.Seq') >0 or str(file).find('.seq') >0 or str(file).find('.json') >0 or str(file).find('.ini') >0 or str(file).find('.bat') >0 or str(file).find('.doc') >0 or str(file).find('.txt') >0 or str(file).find('.py') >0 or str(file).find('.exe') >0 or str(file).find('.xlsx') >0 or str(file).find('.rar') >0 or str(file).find('.dll') >0 or str(file).find('.lib') >0 or str(file).find('.h') >0 or str(file).find('.Seq') >0:
            #print(folder)
            Flist.append(file)
    return  Flist

#Create_FTP_Dir('192.168.200.2','Manh','Manh!!','data/U46L386.01/FT1/a/b/c')
#Upload_File('192.168.200.2','Manh','Manh!!','data','newFolder')
'''def Download_Module(ModuleName):
    moduleplace='D:/Test_Program/Module/' + ModuleName
    if not os.path.isdir(moduleplace):
        os.makedirs(moduleplace)
    Folderlists = Folder_List('200.168.104.98', 'Manh', 'Manh!!', ModuleName)
    Filelists = File_List('200.168.104.98', 'Manh', 'Manh!!', ModuleName)
    for file in Filelists:
        print(file)
        if not Download_File('200.168.104.98', 'Manh', 'Manh!!', ModuleName,moduleplace,file):return False
    for folder in Folderlists:
        print(folder)
        if not os.path.isdir('D:/Test_Program/Module/'+ModuleName+'/'+folder):
            os.makedirs('D:/Test_Program/Module/'+ModuleName+'/'+folder)
        subFilelist = File_List('200.168.104.98', 'Manh', 'Manh!!', ModuleName+'/' + folder)
        for subfile in subFilelist:
            print(subfile)
            if not Download_File('200.168.104.98', 'Manh', 'Manh!!', ModuleName+'/' + folder, moduleplace+'/'+folder, subfile): return False
    return True'''
def Download_Module(ModuleName):
    moduleplace='D:/Test_Program/Module/' + ModuleName
    if not os.path.isdir(moduleplace):
        os.makedirs(moduleplace)
    Folderlists = Folder_List(ftp_ip, ftp_user, ftp_password, 'Module/'+ModuleName)
    Filelists = File_List(ftp_ip, ftp_user, ftp_password, 'Module/'+ModuleName)
    ftp_connection = ftplib.FTP(ftp_ip, timeout=15)
    ftp_connection.login(ftp_user, ftp_password)
    ftp_connection.set_pasv(False)
    ftp_connection.cwd('Module/'+ModuleName)
    time.sleep(0.5)
    file_num=0
    for file in Filelists:
        print(file)
        #if not Download_File('200.168.104.98', 'Manh', 'Manh!!', ModuleName,moduleplace,file):return False
        #bResult = False
        try:
            localfile = open(moduleplace + '/' + file, 'wb')
            if not ftp_connection.retrbinary('RETR ' + file, localfile.write, 1001024):
                return False
            file_num += 1

            #return bResult
        except:
            print('download ' + moduleplace + '/' + file + ' failed')
            return False
    for folder in Folderlists:
        print('----'+str(folder))
        if not os.path.isdir('D:/Test_Program/Module/'+ModuleName+'/'+folder):
            os.makedirs('D:/Test_Program/Module/'+ModuleName+'/'+folder)
        subFilelist = File_List(ftp_ip, ftp_user, ftp_password, 'Module/'+ModuleName+'/' + folder)
        for subfile in subFilelist:
            print(subfile)
            if not Download_File(ftp_ip, ftp_user, ftp_password, 'Module/'+ModuleName+'/' + folder, moduleplace+'/'+folder, subfile): return False
            # bResult = False
            try:
                localfile = open(moduleplace+'/'+folder + '/' + subfile, 'wb')
                if not ftp_connection.retrbinary('RETR ' + subfile, localfile.write, 1001024):
                    return False
                file_num += 1
            except:
                print('download ' + moduleplace+'/'+folder + '/' + subfile + ' failed')
                return False
    ftp_connection.quit()
    localfile.close()
    ftp_connection.close()
    time.sleep(1)
    if os.path.isfile(moduleplace+'/'+ModuleName+'.zip'):
        zip_ref = zipfile.ZipFile(moduleplace+'/'+ModuleName+'.zip', 'r')
        zip_ref.extractall(moduleplace)
        zip_ref.close()
    return file_num


def list_all_ftp_files(ftp, dir):
    dirs = []
    non_dirs = []

    '''Capture the print output of ftp.dir'''
    stream = io.StringIO()
    sys.stdout = stream
    ftp.dir(dir)
    streamed_result = stream.getvalue()

    reduced = [x for x in streamed_result.split(' ') if x != '']

    '''Clean up list'''
    reduced = [x.split('\n')[0] for x in reduced]

    '''Get the names of the folders by which ones are labeled <DIR>'''
    indexes = [ix + 1 for ix, x in enumerate(reduced) if x == '<DIR>']

    folders = [reduced[ix] for ix in indexes]

    if dir == '/':
        non_folders = [x for x in ftp.nlst() if x not in folders]
    else:
        non_folders = [x for x in ftp.nlst(dir) if x not in folders]
        non_folders = [dir + '/' + x for x in non_folders]
        folders = [dir + '/' + x for x in folders]

    '''If currently scanning the root directory, just add the initial set of
       of folders in that directory to our grand list'''
    if dirs == []:
        dirs.extend(folders)
        '''Similarly, do the same for files that are not folders'''
    if non_dirs == []:
        non_dirs.extend(non_folders)

    '''If there are still sub-folders within a directory, keep searching deeper
       potential other sub-folders'''
    if len(folders) > 0:
        for sub_folder in sorted(folders):
            result = list_all_ftp_files(ftp, sub_folder)
            dirs.extend(result[0])
            non_dirs.extend(result[1])

    '''Return the list of all directories on the FTP Server, along
       with the list of all non-folder files'''
    return dirs, non_dirs


'''def Download_Module_New(ModuleName):
    ftp_connection = ftplib.FTP(ftp_ip, timeout=15)
    ftp_connection.login(ftp_user, ftp_password)
    ftp_connection.set_pasv(False)
    ftp_connection.cwd('Module/' + ModuleName)
    folders, files = list_all_ftp_files(ftp_connection, '/')
    file_mapper = {}
    for file in files:
        r = io.BytesIO()
        ftp_connection.retrbinary('RETR ' + file, r.write)
        file_mapper[file] = r
        r.close()
    for key, val in file_mapper.items():
        if not os.path.exists(os.path.dirname(key)):
            os.makedirs(os.path.dirname(key))'''

'''import sys
import ftplib
import os
from ftplib import FTP


def fetchFiles(ftp, path, destination, overwrite=True):
    #Fetch a whole folder from ftp. \n
    #Parameters
    ----------
    #ftp         : ftplib.FTP object
    #path        : string ('/dir/folder/')
    #destination : string ('D:/dir/folder/') folder where the files will be saved
    #overwrite   : bool - Overwrite file if already exists.

    try:
        ftp.cwd(path)
        if not os.path.isdir(destination):
            os.mkdir(destination)
            print('New folder made: ' + destination)
    except OSError:
        # folder already exists at the destination
        pass
    except ftplib.error_perm:
        # invalid entry (ensure input form: "/dir/folder/")
        print("error: could not change to " + path)
        sys.exit("ending session")

    # list children:
    filelist = [i for i in ftp.mlsd()]
    print('Current folder: ' + filelist.pop(0)[0])
    fullpath = destination
    for file in filelist:
        print(file)
        #print(file[1]['type'])
        if file[1]['type'] == 'file':
            print('file')
            try:

                fullpath = os.path.join(destination, file[0])
                print(fullpath)
                if (not overwrite and os.path.isfile(fullpath)):
                    print('fi')
                    continue
                print('sub')
            except:
                print('no sub')
            else:
                with open(fullpath, 'wb') as f:
                    ftp.retrbinary('RETR ' + file[0], f.write)
                print(file[0] + '  downloaded')
                #print('filee')
        elif file[1]['type'] == 'dir':
            print('dirr')
            fetchFiles(ftp, path+'/' + file[0], destination+'/'+file[0], overwrite)
        else:
            print('Unknown type: ' + file[1]['type'])


if __name__ == "__main__":
    ftp = FTP('192.168.200.2')
    ftp.login('Manh', 'Manh!!')
    source = r'/document/data/Module/RIP/'
    dest = r'D:/Test_program/Module/RIP'
    fetchFiles(ftp, source, dest, overwrite=True)
    ftp.quit()'''
'''zip_ref = zipfile.ZipFile('D:/Test_Program/Module/RIP/RIP.zip', 'r')
zip_ref.extractall('D:/Test_Program/Module/RIP/')
zip_ref.close()'''
#Download_Module('RIP')
#cpt = sum([len(files) for r, d, files in os.walk('D:/Documents/Don tu')])
#print(cpt)

'''ftp_connection = ftplib.FTP('10.228.110.181', timeout=15)
ftp_connection.login('Manh', 'Manh!!')
ftp_connection.set_pasv(False)
#ftp_connection.cwd('')
# Get All Files
time.sleep(2)
folders = ftp_connection.nlst()
contents = ftp_connection.retrlines('LIST')
print(contents)
print(folders)'''