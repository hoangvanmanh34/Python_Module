import sys,time
import os,socket
from ast import literal_eval
import threading
from PyQt4.QtCore import *
from PyQt4.QtGui  import *
#from PyQt4.QtWidgets import *
from datetime import datetime
import GUI_HiPot
import cv2
import re
import qimage2ndarray
import serial
import csv
import ctypes
import pyzbar.pyzbar as pyzbar
sorted(pyzbar.ZBarSymbol.__members__.keys())
symlist = re.compile('[@_!#$%^&*()<>?/|}{~:]')


path_sn=r'D:\Test_Program\U46P436.00\HiPot\sn.txt'
path_config=r'D:\Test_Program\U46P436.00\HiPot\config.json'

CFG_file = open(path_config, 'r')
CFG_data = CFG_file.read().strip()
print (CFG_data)
CFG_file.close()
cfg_value_list = literal_eval(CFG_data)
Model=cfg_value_list['Model_name']
Station=cfg_value_list['Station']
PREFIX_SN=cfg_value_list['PREFIX_SN']
LENGTH_SN=int(cfg_value_list['LENGTH_SN'])
COM_SFC=cfg_value_list['COM_SFC']
COM_HIPOT=cfg_value_list['COM_HIPOT']
DELAY=int(cfg_value_list['DELAY'])

Station_name=socket.gethostname()

if os.path.isfile(path_sn):
    os.remove(path_sn)

class App(QMainWindow,GUI_HiPot.Ui_MainWindow):
    value_barcode=pyqtSignal(str)
    display=pyqtSignal(QPixmap)
    sig_time_test=pyqtSignal(str)
    sig_test_status = pyqtSignal(str,str)
    sig_log=pyqtSignal(str)
    sig_clear_log = pyqtSignal()
    sig_count_total = pyqtSignal(int)
    sig_count_p_f = pyqtSignal(int,int)
    def __init__(self):
        super(App, self).__init__()
        self.setupUi(self)

        CAMlist = [str('0'), str('1'), str('2'), str('3'), str('4'), str('5')]
        self.comboBox.addItems(CAMlist)

        self.sn=''
        self.sn1=''
        self.zoom=False
        self.total=0
        self.copass=0
        self.cofail=0
        self.result=''

        self.isRunning=False
        self.error_code=''
        self.test_off=True
        self.flag_send_sfc='standby'
        self.flag_send_start_sfc=True
        self.flag_send_end_sfc = True

        self.count_total = QLabel()
        self.count_total.setText('TOTAL: '+str(self.total))
        self.count_total.setFixedWidth(200)
        self.count_pass_fail = QLabel()
        self.count_pass_fail.setText('PASS: '+str(self.copass)+'/FAIL: '+str(self.cofail))
        self.count_pass_fail.setFixedWidth(200)
        self.statusbar.addPermanentWidget(self.count_total)
        self.statusbar.addPermanentWidget(self.count_pass_fail)

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('Manual')
        Manual_action = QAction('Test Manual', self)
        fileMenu.addAction(Manual_action)

        self.label.setStyleSheet("background-color: lightyellow")
        self.label_2.setStyleSheet("background-color: lightskyblue")
        self.label_3.setStyleSheet("background-color: lightskyblue")
        self.label_4.setStyleSheet("background-color: lightskyblue")
        self.label_5.setStyleSheet("background-color: lightskyblue")
        self.label_6.setStyleSheet("background-color: lightskyblue")

        self.Open_com_hp()
        threading.Thread(target=self.Open_com_sfc).start()

        self.pushButton.clicked.connect(self.Open_cam)
        self.display.connect(self.display_cam)
        self.sig_time_test.connect(self.Show_test_time)
        self.sig_test_status.connect(self.Show_test_status)
        self.sig_log.connect(self.Show_log)
        self.value_barcode.connect(self.recv_sn)
        self.sig_clear_log.connect(self.Clear_log)
        self.sig_count_total.connect(self.Show_total)
        self.sig_count_p_f.connect(self.Show_Pass_Fail)
        Manual_action.triggered.connect(self.Manual_test)

    def Manual(self):
        time.sleep(DELAY)
        self.error_code=''
        if not self.hp_action():
            self.cofail+=1
            self.sig_count_p_f.emit(self.copass,self.cofail)
            self.sig_test_status.emit(self.error_code, 'red')
        else:
            self.copass+=1
            self.sig_count_p_f.emit(self.copass, self.cofail)
            self.sig_test_status.emit('PASS', 'green')
        self.total+=1
        self.sig_count_total.emit(self.total)
        self.isRunning=False
        self.test_off=True

    def Manual_test(self):
        if (str(self.pushButton.text()).find("INIT") != -1):
            if self.test_off==True:
                self.test_off=False
                self.sig_clear_log.emit()
                threading.Thread(target=self.Run_time).start()
                threading.Thread(target=self.Manual).start()


    def recv_sn(self,txt):
        self.sig_clear_log.emit()
        self.sn=txt
        self.sig_log.emit('SN: ' + self.sn)
        check = ctypes.windll.user32.MessageBoxW(0, 'Dong Khuon Truoc Khi Test', 'CLOSE FIXTURE', 0)
        if check == 1:
            self.start_send_sfc()

    def start_send_sfc(self):
        try:
            threading.Thread(target=self.Run_time).start()
            self.flag_send_sfc='start'
            self.flag_send_start_sfc=False
            self.SFC_COM.write(self.sn.encode() + '\r\n'.encode())
            self.sig_log.emit('Send SFC Start: ' + self.sn)
            threading.Thread(target=self.Can_not_rec_sfc_start).start()
        except Exception as e:
            print('start send sfc: ',e)
            self.sn=''
            self.sn1=''
            self.isRunning=False

    def Can_not_rec_sfc_start(self):
        time.sleep(3)
        if self.flag_send_start_sfc==False:
            self.sig_test_status.emit('ID0005', 'red')
            self.sn = ''
            self.sn1 = ''
            self.isRunning = False

    def Rev_start_sfc(self,data):
        self.flag_send_sfc='standby'
        self.flag_send_start_sfc=True
        self.sig_log.emit('Recieve SFC_start: ' + data)
        if len(data.split('PASS')[0]) == 49 and data.find(self.sn) == 0 and data.find('PASS') == 49:
            threading.Thread(target=self.Start_hp).start()
        elif len(data) > 0 and (len(data.split('PASS')[0]) != 49 or data.find(self.sn) != 0 or data.find('PASS') != 49):
            self.sig_test_status.emit('ID0005','red')
            self.sn=''
            self.sn1=''
            self.isRunning=False

    def Start_hp(self):
        time.sleep(DELAY)
        self.error_code=''
        self.hp_action()
        self.send_end_sfc()

    def hp_action(self):
        stop = [0xAB, 0x01, 0x70, 0x01, 0x21, 0x6D, 0x99, 0x99]
        start = [0xAB, 0x01, 0x70, 0x01, 0x22, 0x6C, 0x99, 0x99]
        result = [0xAB, 0x01, 0x70, 0x03, 0xB1, 0x00, 0xD7, 0x04]
        # self.HP_COM.SERIAL_WRITE(serial.to_bytes(stop))
        self.HIPOT_COM.write(serial.to_bytes(stop))
        print('stop')
        #self.HP_COM.SERIAL_WRITE('12345678910            PASS ')
        time.sleep(2)
        # res = (self.HP_COM.SERIAL_READ())
        res=(self.HIPOT_COM.read_all().strip())
        print(res)
        self.sig_log.emit(str(res))
        #self.Log_line += res + '\n'
        expect = b'\xabp\x01\x02\x7f\x00\x0e'
        if str(res).find(str(expect)) >=0 :
            #self.HP_COM.SERIAL_WRITE(serial.to_bytes("\xAB\x01\x70\x01\x22\x6C\x99\x99"))
            # self.HP_COM.SERIAL_WRITE(serial.to_bytes(start))
            self.HIPOT_COM.write(serial.to_bytes(start))
            print('start')
            time.sleep(2)
            # res = (self.HP_COM.SERIAL_READ())
            res=(self.HIPOT_COM.read_all().strip())
            print(res)
            self.sig_log.emit(str(res))
            #self.Log_line += res + '\n'
            if str(res).find(str(expect)) >=0:
                a=b'\xabp\x01\x12\xb1\x00\x01\x14\xd7\x01\x00\x00\x00\xca\x9a;\x00\x00\x01\x00\x00\x00?'
                for i in range(0, 25):
                    # self.HP_COM.SERIAL_WRITE(serial.to_bytes(result))
                    self.HIPOT_COM.write(serial.to_bytes(result))
                    time.sleep(0.5)
                    # res = (self.HP_COM.SERIAL_READ())
                    res = (self.HIPOT_COM.read_all().strip())
                    #self.Log_line += res + '\n'
                    print(res)
                    self.sig_log.emit(str(res))
                else:
                    if str(res).find(str(a)) >= 0:
                        self.error_code = "HIPO00"
                        return False
            else:
                self.error_code = "HIPO00"
                return False
        else:
            self.error_code = "HIPO00"
            return False
        return True

    def send_end_sfc(self):
        self.flag_send_sfc='end'
        self.flag_send_end_sfc=False
        self.sn1=self.sn.ljust(25,' ')
        self.send_end = self.sn1+ Station_name + self.error_code
        self.SFC_COM.write(self.send_end.encode() + '\r\n'.encode())
        self.sig_log.emit('Send SFC End: ' + self.send_end)
        threading.Thread(target=self.Can_not_send_end_sfc).start()

    def Can_not_send_end_sfc(self):
        time.sleep(3)
        if self.flag_send_end_sfc==False:
            self.result='FAIL'
            self.error_code='ID0005'
            self.cofail+=1
            self.sig_count_p_f.emit(self.copass,self.cofail)
            self.sig_test_status.emit(self.error_code, 'red')
            self.total += 1
            self.sig_count_total.emit(self.total)
            self.Save_log()
            self.sn = ''
            self.sn1 = ''
            self.isRunning = False

    def Rev_end_sfc(self,data):
        self.flag_send_end_sfc=True
        self.flag_send_sfc='standby'
        self.sig_log.emit('Recieve SFC_end: ' + data)
        if data.find(self.send_end + 'PASS') == 0:
            self.result='PASS'
            self.copass+=1
            self.sig_count_p_f.emit(self.copass,self.cofail)
            self.sig_test_status.emit('PASS', 'green')
        elif data.find('R_') > 0 or data.find('TE FORMAT ERROR') > 0 or data.find('unique constraint') > 0 or data.find('INS_ATE_COMBINE_FINAL') > 0 or data.find(self.send_end) != 0:
            self.error_code = 'ID0005'
        if len(self.error_code) > 0:
            self.result='FAIL'
            self.cofail += 1
            self.sig_count_p_f.emit(self.copass,self.cofail)
            self.sig_test_status.emit(self.error_code,'red')
        self.total += 1
        self.sig_count_total.emit(self.total)
        self.Save_log()
        self.sn=''
        self.sn1=''
        self.isRunning=False

    def Save_log(self):
        datetosave = str(datetime.now().__format__('%d-%m-%Y'))
        timetosave = str(datetime.now().__format__('%d-%m-%Y_%H-%M-%S'))

        full_savedir = 'D:/Logs/' + Model + '/' + Station + '/' + Station_name + '/' + datetosave
        if not os.path.isdir(full_savedir): os.makedirs(full_savedir)
        log_file = open(full_savedir + '/' + self.sn +'_' + timetosave + '_' + self.error_code + '.txt','w')
        log_file.write(str(self.textEdit.toPlainText()))
        log_file.close()
        sum_head = [['Roco_SN', 'Result', 'Error_Code', 'Finish_Date_Time', 'Test_Time']]
        if not os.path.isfile(full_savedir + '/Summary_Log.csv'):
            with open(full_savedir + '/Summary_Log.csv', 'w', newline='') as summary:
                write_summary = csv.writer(summary)
                write_summary.writerows(sum_head)

        list_summary1 = []
        with open(full_savedir + '/Summary_Log.csv', newline='') as summary:
            read_summary = csv.reader(summary)
            for row in read_summary:
                list_summary1.append(row)

        list_summary2 = [[str(self.sn), str(self.result), str(self.error_code), str(timetosave), str(self.time_test)]]
        with open(full_savedir + '/Summary_Log.csv', 'w', newline='') as summary:
            write_summary = csv.writer(summary)
            write_summary.writerows(list_summary1)
            write_summary.writerows(list_summary2)

    def Open_com_hp(self):
        try:
            self.HIPOT_COM = serial.Serial(COM_HIPOT)
        except:
            print('open com hp fail')

    def Open_com_sfc(self):
        try:
            self.SFC_COM = serial.Serial(COM_SFC)
            while True:
                value_com=self.SFC_COM.read_all().decode()
                if len(value_com)>0:
                    if self.flag_send_sfc=='start':
                        self.Rev_start_sfc(value_com)
                    elif self.flag_send_sfc=='end':
                        self.Rev_end_sfc(value_com)
        except:
            print('open com sfc fail')


    def Run_time(self):
        self.isRunning=True
        self.time_test=0
        self.sig_time_test.emit(str(self.time_test))
        self.sig_test_status.emit('RUNNING','yellow')
        while self.isRunning:
            time.sleep(1)
            self.time_test+=1
            self.sig_time_test.emit(str(self.time_test))

    def Show_test_time(self,time):
        self.label_4.setText(time)

    def Show_test_status(self,status,color):
        self.label_5.setText(status)
        self.label_5.setStyleSheet("background-color: lightskyblue; color: " + color)

    def Show_log(self,log):
        self.textEdit.append(log)
        self.textEdit.moveCursor(QTextCursor.End)

    def Clear_log(self):
        self.textEdit.clear()

    def Show_total(self,total):
        self.count_total.setText('TOTAL: ' + str(total))

    def Show_Pass_Fail(self,cpass,cfail):
        self.count_pass_fail.setText('PASS: ' + str(cpass) + '/FAIL: ' + str(cfail))

    def Open_cam(self):
        if (str(self.pushButton.text()).find("INIT") != -1):
            self.pushButton.setText("OPEN")
            self.pushButton.setStyleSheet("color: green")
            self.comboBox.setDisabled(True)
            threading.Thread(target=self.Init_cam).start()
        elif (str(self.pushButton.text()).find("OPEN") != -1):
            self.pushButton.setText("INIT")
            self.pushButton.setStyleSheet("color: red")
            self.comboBox.setEnabled(True)
            self.Close_cam()

    def Init_cam(self):
        self.capture = cv2.VideoCapture(int(self.comboBox.currentText()), cv2.CAP_DSHOW)
        while self.capture.isOpened():
            pre_barcode = ''
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            ret, self.frame = self.capture.read()
            decodedObjects = pyzbar.decode(self.frame, symbols=[pyzbar.ZBarSymbol.QRCODE, pyzbar.ZBarSymbol.CODE128,pyzbar.ZBarSymbol.CODE93])
            for obj in decodedObjects:
                (x, y, w, h) = obj.rect
                self.frame = cv2.rectangle(self.frame, (x, y), (x + w, y + h), (0, 255, 0), 5)
                barcodeData = obj.data.decode("utf-8")
                barcodeType = obj.type
                if barcodeType == 'CODE128' or barcodeType == 'CODE93':
                    if os.path.isfile(path_sn):
                        with open(path_sn, 'r') as readbar:
                            pre_barcode = readbar.read()
                    if (barcodeData.find(PREFIX_SN) >= 0 and len(barcodeData) == LENGTH_SN):
                        text = "{} ({})".format(barcodeData, barcodeType)
                        self.frame = cv2.putText(self.frame, text, (50, 50), cv2.FONT_HERSHEY_PLAIN, 2, (0, 0, 255), 2)
                    elif barcodeData.find(PREFIX_SN) != 0 and len(barcodeData) != LENGTH_SN:
                        text = "{} ({})(Wrong)".format(barcodeData, barcodeType)
                        self.frame = cv2.putText(self.frame, text, (50, 50), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 2)
                    if pre_barcode.find(barcodeData) == -1 and barcodeData.find(PREFIX_SN) == 0 and len(
                            barcodeData) == LENGTH_SN and re.search(symlist, barcodeData) == None:
                        print("[INFO] Found {}: {}".format(barcodeType, barcodeData))
                        self.value_barcode.emit(str(barcodeData))
                        with open(path_sn, 'w') as readbar1:
                            readbar1.writelines(barcodeData)
            # self.display_cam()
            img = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
            qimg = qimage2ndarray.array2qimage(img)
            pixmap = QPixmap(qimg)
            self.display.emit(pixmap)
            cv2.waitKey(100)

    def Close_cam(self):
        try:
            self.capture.release()
        except:
            pass

    def display_cam(self, pixmap):
        if not self.zoom:
            pixmap = pixmap.scaled(self.label.width(), self.label.height(), aspectRatioMode=Qt.KeepAspectRatio)
        self.label.setPixmap(pixmap)
        self.label.show()


app = QApplication(sys.argv)
ex = App()
ex.show()
sys.exit(app.exec_())
