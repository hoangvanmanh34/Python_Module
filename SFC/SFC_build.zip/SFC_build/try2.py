import json
import re
import os
import glob
pattern = r'Check \"Factory reset\" key'
os.chdir("C:\\Trinity\\TestJson_out\\Moved")
for logj in glob.glob("*.json"):
    print logj
    f=open("C:\\Trinity\\TestJson_out\\Moved\\"+logj,"r")
    str_data = f.read().replace("'", "-")
    print str_data
    #org_data = json.loads(str_data)
    org_data=json.loads(str_data)
    f.close()
    new_data = '{\
        "TestGate": "",\
        "ModelName": "",\
        "TestStation": "",\
        "TestStationName": "",\
        "TEST_DATA":{}\
    }'
    new_data_json = json.loads(new_data)
    new_data_json["TestGate"] = org_data['TestContext']["TestGate"]
    new_data_json["ModelName"] = org_data['TestContext']["ModelName"]
    new_data_json["TestStation"] = org_data['TestContext']["TestStation"]
    new_data_json["TEST_DATA"] = {}

    org_test_data_list = org_data['TestContext']["TestSteps"]

    for i in range(0, len(org_test_data_list)):
        print(i)
        idata = str(org_test_data_list[i]).replace("'", '"')
        idata = re.sub(pattern, 'Check Factory reset key', idata)
        org_test_data_json = json.loads(idata)
        # print(org_test_data_json)
        new_data_json["TEST_DATA"][org_test_data_json["TestName"] + '_TEST_TIME'] = org_test_data_json["TestTime"]

    # for i in new_data_json:
    #    print(i)

    json_object = json.dumps(new_data_json, indent=4)

    # ----------- Writing json FILE
    with open("file_nay_la_moi_nhat.json", "w") as outfile:
        outfile.write(json_object)
